locals {
  storage_vm_instance_id = google_compute_instance.lab["storage"].instance_id
}

resource "google_monitoring_notification_channel" "email" {
  count        = var.enable_cpu_alert ? 1 : 0
  project      = var.project_id
  display_name = "${local.prefix} Day 6 CPU alert email"
  type         = "email"
  enabled      = true

  labels = {
    email_address = var.alert_email
  }

  lifecycle {
    precondition {
      condition     = length(trimspace(var.alert_email)) > 5 && can(regex("^[^@ ]+@[^@ ]+\\.[^@ ]+$", var.alert_email))
      error_message = "Set alert_email to a valid monitored email address before enabling the CPU alert."
    }
  }
}

resource "google_monitoring_alert_policy" "cpu" {
  count        = var.enable_cpu_alert ? 1 : 0
  project      = var.project_id
  display_name = "${local.prefix} Day 6 storage VM CPU above 60 percent (P1 training alert)"
  combiner     = "OR"
  enabled      = true
  severity     = "CRITICAL"
  documentation {
    content   = "Day 6 lab alert. Confirm whether the CPU load is expected, then capture incident and notification evidence."
    mime_type = "text/markdown"
  }

  conditions {
    display_name = "Storage VM CPU utilization above 60 percent for 1 minute"
    condition_threshold {
      filter = "metric.type=\"compute.googleapis.com/instance/cpu/utilization\" AND resource.type=\"gce_instance\" AND resource.label.instance_id=\"${local.storage_vm_instance_id}\""
      comparison      = "COMPARISON_GT"
      threshold_value = 0.6
      duration        = "60s"

      aggregations {
        alignment_period   = "60s"
        per_series_aligner = "ALIGN_MEAN"
      }

      trigger {
        count = 1
      }
    }
  }

  notification_channels = [google_monitoring_notification_channel.email[0].name]
  depends_on             = [google_project_service.apis]
}
