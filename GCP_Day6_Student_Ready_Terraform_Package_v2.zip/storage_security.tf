resource "google_storage_bucket" "lab" {
  name                        = "${var.name_prefix}-${var.project_id}-artifacts"
  project                     = var.project_id
  location                    = var.region
  force_destroy               = true
  uniform_bucket_level_access = true
  public_access_prevention    = "inherited"
  labels                      = local.common_labels

  dynamic "encryption" {
    for_each = var.enable_cmek ? [google_kms_crypto_key.lab[0].id] : []
    content {
      default_kms_key_name = encryption.value
    }
  }

  depends_on = [
    google_project_service.apis,
    google_kms_crypto_key_iam_member.storage_agent,
  ]
}

resource "google_storage_bucket_object" "sample" {
  name         = "internal-reports/day6-synthetic-report.txt"
  bucket       = google_storage_bucket.lab.name
  content      = "DAY6 TRAINING ONLY - synthetic, non-sensitive sample object. Do not upload production data.\n"
  content_type = "text/plain"
}

resource "google_storage_bucket_iam_member" "public_fault" {
  count  = var.enable_public_bucket_fault ? 1 : 0
  bucket = google_storage_bucket.lab.name
  role   = "roles/storage.objectViewer"
  member = "allUsers"
}

resource "google_kms_key_ring" "lab" {
  count    = var.enable_cmek ? 1 : 0
  name     = "${local.prefix}-keyring"
  location = var.region
  project  = var.project_id
  depends_on = [google_project_service.apis]
}

resource "google_kms_crypto_key" "lab" {
  count           = var.enable_cmek ? 1 : 0
  name            = "${local.prefix}-cmek"
  key_ring        = google_kms_key_ring.lab[0].id
  purpose         = "ENCRYPT_DECRYPT"
  rotation_period = "7776000s" # 90 days; this config schedules rotation, it does not immediately rotate a key.

  lifecycle {
    prevent_destroy = true
  }
}

data "google_storage_project_service_account" "gcs" {
  count   = var.enable_cmek ? 1 : 0
  project = var.project_id
  depends_on = [google_project_service.apis]
}

resource "google_kms_crypto_key_iam_member" "storage_agent" {
  count         = var.enable_cmek ? 1 : 0
  crypto_key_id = google_kms_crypto_key.lab[0].id
  role          = "roles/cloudkms.cryptoKeyEncrypterDecrypter"
  member        = "serviceAccount:${data.google_storage_project_service_account.gcs[0].email_address}"
}

resource "google_secret_manager_secret" "db_password" {
  secret_id = "${local.prefix}-db-password"
  project   = var.project_id
  labels    = local.common_labels

  replication {
    auto {}
  }

  deletion_protection = false
  depends_on           = [google_project_service.apis]
}


resource "google_storage_bucket_iam_member" "operator_bucket_admin" {
  count  = var.operator_email == "" ? 0 : 1
  bucket = google_storage_bucket.lab.name
  role   = "roles/storage.admin"
  member = "user:${var.operator_email}"
}

resource "google_secret_manager_secret_iam_member" "operator_version_manager" {
  count     = var.operator_email == "" ? 0 : 1
  project   = var.project_id
  secret_id = google_secret_manager_secret.db_password.secret_id
  role      = "roles/secretmanager.secretVersionManager"
  member    = "user:${var.operator_email}"
}
