data "google_project" "current" {
  project_id = var.project_id
}

locals {
  prefix = "${var.name_prefix}-${substr(var.project_id, 0, 8)}"

  common_labels = {
    environment = "training"
    course_day  = "day6"
    managed_by  = "terraform"
  }

  required_apis = toset([
    "cloudresourcemanager.googleapis.com",
    "compute.googleapis.com",
    "iam.googleapis.com",
    "iamcredentials.googleapis.com",
    "iap.googleapis.com",
    "storage.googleapis.com",
    "cloudkms.googleapis.com",
    "secretmanager.googleapis.com",
    "monitoring.googleapis.com",
    "logging.googleapis.com",
    "serviceusage.googleapis.com",
  ])
}

resource "google_project_service" "apis" {
  for_each = local.required_apis

  project                    = var.project_id
  service                    = each.value
  disable_on_destroy         = false
  disable_dependent_services = false
}

resource "google_compute_network" "lab" {
  name                    = "${local.prefix}-vpc"
  auto_create_subnetworks = false
  routing_mode            = "REGIONAL"
  description             = "Isolated Day 6 training VPC."
  depends_on              = [google_project_service.apis]
}

resource "google_compute_subnetwork" "lab" {
  name                     = "${local.prefix}-subnet"
  region                   = var.region
  network                  = google_compute_network.lab.id
  ip_cidr_range             = var.subnet_cidr
  private_ip_google_access = true
  description              = "Private subnet for Day 6 GCP operations lab."
}

resource "google_compute_firewall" "allow_iap_ssh" {
  name        = "${local.prefix}-allow-iap-ssh"
  network     = google_compute_network.lab.name
  description = "Allow SSH only from the Google IAP TCP forwarding range to tagged lab VMs."
  direction   = "INGRESS"
  priority    = 1000
  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["d6-iap-ssh"]

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }
}

resource "google_compute_firewall" "deny_iap_ssh" {
  count       = var.enable_firewall_deny ? 1 : 0
  name        = "${local.prefix}-deny-iap-ssh"
  network     = google_compute_network.lab.name
  description = "Intentional capstone fault: blocks IAP SSH before the allow rule."
  direction   = "INGRESS"
  priority    = 900
  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["d6-iap-ssh"]

  deny {
    protocol = "tcp"
    ports    = ["22"]
  }
}

resource "google_service_account" "vm_runtime" {
  account_id   = "${local.prefix}-vm-runtime"
  display_name = "Day 6 VM runtime identity (no project roles assigned)"
  description  = "Dedicated runtime identity for lab VMs; no broad project permissions are granted."
  depends_on   = [google_project_service.apis]
}

resource "google_service_account" "responder" {
  account_id   = "${local.prefix}-responder"
  display_name = "Day 6 IAM Deny test identity"
  description  = "Synthetic identity used only to prove Allow versus Deny precedence."
  depends_on   = [google_project_service.apis]
}

resource "google_project_iam_member" "responder_viewer_allow" {
  count   = var.enable_responder_allow ? 1 : 0
  project = var.project_id
  role    = "roles/compute.viewer"
  member  = "serviceAccount:${google_service_account.responder.email}"
}

resource "google_service_account_iam_member" "operator_responder_token_creator" {
  count              = var.operator_email == "" ? 0 : 1
  service_account_id = google_service_account.responder.name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = "user:${var.operator_email}"
}

resource "google_service_account_iam_member" "operator_vm_act_as" {
  count              = var.operator_email == "" ? 0 : 1
  service_account_id = google_service_account.vm_runtime.name
  role               = "roles/iam.serviceAccountUser"
  member             = "user:${var.operator_email}"
}

resource "google_project_iam_member" "operator_access_roles" {
  for_each = var.operator_email == "" ? toset([]) : toset([
    "roles/compute.viewer",
    "roles/compute.instanceAdmin.v1",
    "roles/compute.networkAdmin",
    "roles/compute.securityAdmin",
    "roles/compute.osAdminLogin",
    "roles/iap.tunnelResourceAccessor",
    "roles/monitoring.editor",
    "roles/cloudkms.admin",
    "roles/serviceusage.serviceUsageAdmin",
  ])

  project = var.project_id
  role    = each.value
  member  = "user:${var.operator_email}"
}

resource "google_iam_deny_policy" "responder_fault" {
  count        = var.enable_iam_deny_fault ? 1 : 0
  parent       = urlencode("cloudresourcemanager.googleapis.com/projects/${var.project_id}")
  name         = "${local.prefix}-responder-deny"
  display_name = "Day 6 capstone - deny responder VM discovery"

  rules {
    description = "Deny compute.instances.get to the synthetic responder identity; the project Viewer Allow remains in place."
    deny_rule {
      denied_principals = ["principal://iam.googleapis.com/projects/-/serviceAccounts/${google_service_account.responder.email}"]
      denied_permissions = ["compute.googleapis.com/instances.get"]
    }
  }
}

resource "google_compute_instance" "lab" {
  for_each = {
    idle = {
      name = "vm-idle"
      tags = ["d6-iap-ssh", "d6-idle"]
    }
    ssh_broken = {
      name = "vm-ssh-broken"
      tags = var.ssh_vm_fixed ? ["d6-iap-ssh"] : ["d6-ssh-broken"]
    }
    storage = {
      name = "vm-storage"
      tags = ["d6-iap-ssh", "d6-storage"]
    }
  }

  name         = "${local.prefix}-${each.value.name}"
  machine_type = var.machine_type
  zone         = var.zone
  tags         = each.value.tags
  labels       = local.common_labels
  description  = "Day 6 training VM (${each.key}); no external IPv4 address."

  boot_disk {
    auto_delete = true
    initialize_params {
      image = "debian-cloud/debian-12"
      size  = 10
      type  = "pd-standard"
    }
  }

  network_interface {
    subnetwork = google_compute_subnetwork.lab.id
  }

  service_account {
    email  = google_service_account.vm_runtime.email
    scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }

  metadata = {
    enable-oslogin = "TRUE"
  }

  allow_stopping_for_update = true
  depends_on = [
    google_project_service.apis,
    google_service_account_iam_member.operator_vm_act_as,
  ]
}

resource "google_compute_disk" "data" {
  name        = "${local.prefix}-data-disk"
  project     = var.project_id
  zone        = var.zone
  type        = "pd-standard"
  size        = var.data_disk_size_gb
  description = "Synthetic Day 6 data disk for safe disk-full and resize exercises."
  labels      = local.common_labels
  depends_on  = [google_project_service.apis]
}

resource "google_compute_attached_disk" "data" {
  disk        = google_compute_disk.data.id
  instance    = google_compute_instance.lab["storage"].id
  zone        = var.zone
  device_name = "d6-data-disk"
  mode        = "READ_WRITE"
}

resource "google_compute_instance_template" "mig" {
  name_prefix  = "${local.prefix}-mig-template-"
  machine_type = var.machine_type
  description  = "Day 6 zonal MIG template. Instances have no external IP addresses."
  tags         = ["d6-mig", "d6-iap-ssh"]
  labels       = local.common_labels

  disk {
    source_image = "debian-cloud/debian-12"
    auto_delete  = true
    boot         = true
    disk_size_gb = 10
    disk_type    = "pd-standard"
  }

  network_interface {
    subnetwork = google_compute_subnetwork.lab.id
  }

  service_account {
    email  = google_service_account.vm_runtime.email
    scopes = ["https://www.googleapis.com/auth/cloud-platform"]
  }

  metadata = {
    enable-oslogin = "TRUE"
  }

  lifecycle {
    create_before_destroy = true
  }

  depends_on = [google_service_account_iam_member.operator_vm_act_as]
}

resource "google_compute_instance_group_manager" "mig" {
  name               = "${local.prefix}-mig"
  base_instance_name = "${local.prefix}-web"
  zone               = var.zone
  target_size        = var.mig_target_size
  description        = "Day 6 zonal Managed Instance Group. Scale from 2 to 4 during the exercise."

  version {
    name              = "primary"
    instance_template = google_compute_instance_template.mig.id
  }
}
