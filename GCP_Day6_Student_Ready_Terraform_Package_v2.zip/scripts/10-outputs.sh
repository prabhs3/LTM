#!/usr/bin/env bash
set -euo pipefail

terraform output
cat <<'EOF'
Use these outputs in the Day 6 runbook. Do not replace generated names with sample names.
EOF
