#!/usr/bin/env bash
set -euo pipefail

command -v gcloud >/dev/null || { echo "gcloud CLI not found. Open Google Cloud Shell."; exit 1; }
command -v terraform >/dev/null || { echo "terraform not found. Install it using Google's official Cloud Shell instructions."; exit 1; }

ACCOUNT="$(gcloud auth list --filter=status:ACTIVE --format='value(account)' | head -n1)"
PROJECT="$(gcloud config get-value project 2>/dev/null)"

printf 'Active account : %s\n' "${ACCOUNT:-<none>}"
printf 'Active project : %s\n' "${PROJECT:-<none>}"
terraform version

if [[ -z "${PROJECT}" || "${PROJECT}" == "(unset)" ]]; then
  echo "Set the allocated project with: gcloud config set project YOUR_EXISTING_PROJECT_ID"
  exit 1
fi

DAY6_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TRANSITION_FILE="$DAY6_ROOT/.day5-transition-cleared"
if [[ ! -f "$TRANSITION_FILE" ]] || [[ "$(head -n1 "$TRANSITION_FILE" 2>/dev/null || true)" != "$PROJECT" ]]; then
  echo "Day 5 -> Day 6 handoff has not been confirmed for the active project."
  echo "Read DAY5_TO_DAY6_HANDOFF.md, then run: ./scripts/00-day5-transition-check.sh"
  exit 2
fi

TFVARS_PROJECT="$(sed -nE 's/^[[:space:]]*project_id[[:space:]]*=[[:space:]]*"([a-z0-9-]+)".*/\1/p' "$DAY6_ROOT/terraform.tfvars" 2>/dev/null | tail -n1)"
if [[ -z "$TFVARS_PROJECT" || "$TFVARS_PROJECT" != "$PROJECT" ]]; then
  echo "terraform.tfvars project_id must match the active gcloud project. Set both to the same allocated training project."
  exit 4
fi

if [[ -f "$DAY6_ROOT/terraform.tfstate" || -d "$DAY6_ROOT/terraform.tfstate.d" || -d "$DAY6_ROOT/.terraform" ]]; then
  echo "Day 6 state or initialization metadata already exists in this directory. Do not treat this as a fresh deployment. Inspect and resume/clean it with its own state."
  exit 3
fi

gcloud projects describe "${PROJECT}" --format='table(projectId,name,lifecycleState)'
gcloud billing projects describe "${PROJECT}" --format='yaml(projectId,billingEnabled)'

echo "Preflight complete. Confirm that the active project is the disposable Day 6 training project before proceeding."
printf 'Before terraform init, run: gcloud services enable serviceusage.googleapis.com cloudresourcemanager.googleapis.com --project=%s\n' "${PROJECT}"
