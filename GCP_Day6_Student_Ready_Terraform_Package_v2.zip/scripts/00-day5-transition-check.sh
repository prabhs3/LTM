#!/usr/bin/env bash
set -euo pipefail

# Human-in-the-loop handoff gate. This script is intentionally read-only.
# It never runs terraform destroy, deletes folders, disables APIs, or removes resources.

command -v gcloud >/dev/null || { echo "gcloud CLI not found. Open Google Cloud Shell."; exit 1; }
command -v terraform >/dev/null || { echo "terraform not found. Open Google Cloud Shell with Terraform installed."; exit 1; }

ACTIVE_PROJECT="$(gcloud config get-value project 2>/dev/null)"
if [[ -z "$ACTIVE_PROJECT" || "$ACTIVE_PROJECT" == "(unset)" ]]; then
  echo "No active project. Run: gcloud config set project YOUR_TRAINING_PROJECT_ID"
  exit 1
fi

DAY5_DIR="${DAY5_DIR:-$HOME/gcp-day5-lab}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DAY6_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

TFVARS_PROJECT="$(sed -nE 's/^[[:space:]]*project_id[[:space:]]*=[[:space:]]*"([a-z0-9-]+)".*/\1/p' "$DAY6_ROOT/terraform.tfvars" 2>/dev/null | tail -n1)"
if [[ -z "$TFVARS_PROJECT" ]]; then
  echo "STOP: terraform.tfvars with a literal project_id was not found. Create it from terraform.tfvars.example first."
  exit 1
fi
if [[ "$TFVARS_PROJECT" != "$ACTIVE_PROJECT" ]]; then
  echo "STOP: terraform.tfvars project_id ($TFVARS_PROJECT) does not match the active gcloud project ($ACTIVE_PROJECT). Set the correct project in both places before continuing."
  exit 1
fi

printf '\nDay 5 -> Day 6 transition check\n'
printf 'Active project : %s\n' "$ACTIVE_PROJECT"
printf 'Day 5 directory: %s\n' "$DAY5_DIR"
printf 'Day 6 directory: %s\n\n' "$DAY6_ROOT"
DAY5_INVENTORY_PROJECT="$ACTIVE_PROJECT"

if [[ -d "$DAY5_DIR" ]]; then
  if [[ -f "$DAY5_DIR/terraform.tfvars" ]]; then
    DAY5_TFVARS_PROJECT="$(sed -nE 's/^[[:space:]]*project_id[[:space:]]*=[[:space:]]*"([a-z0-9-]+)".*/\1/p' "$DAY5_DIR/terraform.tfvars" | tail -n1)"
    [[ -n "$DAY5_TFVARS_PROJECT" ]] && DAY5_INVENTORY_PROJECT="$DAY5_TFVARS_PROJECT"
  fi
  if [[ -d "$DAY5_DIR/.terraform" || -f "$DAY5_DIR/terraform.tfstate" || -d "$DAY5_DIR/terraform.tfstate.d" ]]; then
    echo "Inspecting the Day 5 workspace/state (read-only):"
    WORKSPACE_LIST="$(terraform -chdir="$DAY5_DIR" workspace list 2>&1)" || { echo "$WORKSPACE_LIST"; echo "STOP: unable to list Day 5 workspaces."; exit 2; }
    printf '%s\n' "$WORKSPACE_LIST"
    NONDEFAULT_WORKSPACES="$(printf '%s\n' "$WORKSPACE_LIST" | sed 's/^\*//' | sed 's/^[[:space:]]*//' | grep -v '^default$' | sed '/^[[:space:]]*$/d' || true)"
    if [[ -n "${NONDEFAULT_WORKSPACES//[[:space:]]/}" ]]; then
      echo "STOP: additional Day 5 Terraform workspaces exist. Inspect/destroy every intended Day 5 workspace separately using its own reviewed plan before continuing."
      exit 2
    fi
    if ! STATE_LIST="$(terraform -chdir="$DAY5_DIR" state list 2>&1)"; then
      echo "$STATE_LIST"
      echo "STOP: Day 5 state could not be read. Do not initialize a new state or delete this folder. Re-open the original Day 5 configuration/backend and resolve it first."
      exit 2
    fi
    MANAGED_STATE_LIST="$(printf '%s\n' "$STATE_LIST" | grep -Ev '(^|\.)data\.' | sed '/^[[:space:]]*$/d' || true)"
    if [[ -n "${MANAGED_STATE_LIST//[[:space:]]/}" ]]; then
      printf '%s\n' "$MANAGED_STATE_LIST"
      echo "STOP: Day 5 state still lists managed resources. Complete and review Day 5 destroy in the Day 5 directory before starting Day 6."
      exit 3
    fi
    echo "No managed resource addresses were returned by terraform state list in the Day 5 workspace."
    if [[ -n "${STATE_LIST//[[:space:]]/}" ]]; then
      echo "Data-source state entries may remain; they do not represent managed infrastructure."
    fi
  else
    echo "Day 5 folder exists but no local state/backend marker was found. This does not prove cleanup."
    echo "If Day 5 used a remote backend or a different folder, set DAY5_DIR to that exact working directory and rerun."
  fi
else
  echo "The default Day 5 folder was not found. This does not prove cleanup."
  echo "If Day 5 used another folder/backend, set DAY5_DIR to that exact path and rerun."
fi

# Detect an existing Day 6 state in this Day 6 root. Do not overwrite/reinitialize it.
if [[ -f "$DAY6_ROOT/terraform.tfstate" || -d "$DAY6_ROOT/terraform.tfstate.d" || -d "$DAY6_ROOT/.terraform" ]]; then
  echo "STOP: Day 6 state or initialization metadata already exists in this directory. Inspect it and resume or destroy it using the Day 6 configuration. Do not overwrite it."
  exit 4
fi

# Check a few deterministic Day 6 resource names to catch an earlier partial deployment
# that is not represented by the current local state. These are read-only describe calls.
NAME_PREFIX="d6"
ZONE="us-central1-a"
if [[ -f "$DAY6_ROOT/terraform.tfvars" ]]; then
  FOUND_PREFIX="$(sed -nE 's/^[[:space:]]*name_prefix[[:space:]]*=[[:space:]]*"([a-z0-9-]+)".*/\1/p' "$DAY6_ROOT/terraform.tfvars" | tail -n1)"
  [[ -n "$FOUND_PREFIX" ]] && NAME_PREFIX="$FOUND_PREFIX"
  FOUND_ZONE="$(sed -nE 's/^[[:space:]]*zone[[:space:]]*=[[:space:]]*"([a-z0-9-]+)".*/\1/p' "$DAY6_ROOT/terraform.tfvars" | tail -n1)"
  [[ -n "$FOUND_ZONE" ]] && ZONE="$FOUND_ZONE"
fi
PROJECT_SHORT="${ACTIVE_PROJECT:0:8}"
RESOURCE_PREFIX="${NAME_PREFIX}-${PROJECT_SHORT}"
if gcloud compute networks describe "${RESOURCE_PREFIX}-vpc" --project="$ACTIVE_PROJECT" >/dev/null 2>&1; then
  echo "STOP: ${RESOURCE_PREFIX}-vpc already exists in the active project but no Day 6 state file was found here. Recover the matching Day 6 state or import after instructor review."
  exit 5
fi
for VM_SUFFIX in vm-idle vm-ssh-broken vm-storage; do
  if gcloud compute instances describe "${RESOURCE_PREFIX}-${VM_SUFFIX}" --zone="$ZONE" --project="$ACTIVE_PROJECT" >/dev/null 2>&1; then
    echo "STOP: ${RESOURCE_PREFIX}-${VM_SUFFIX} already exists but no Day 6 state was found here. Recover the matching Day 6 state or import after instructor review."
    exit 5
  fi
done
BUCKET_NAME="${NAME_PREFIX}-${ACTIVE_PROJECT}-artifacts"
if gcloud storage buckets describe "gs://${BUCKET_NAME}" >/dev/null 2>&1; then
  echo "STOP: gs://${BUCKET_NAME} already exists but no Day 6 state was found here. Confirm ownership and recover/import only after instructor review."
  exit 5
fi

cat <<EOF2

Read-only project inventory for manual comparison with the Day 5 outputs captured before destroy:
EOF2
printf '\n--- Compute Engine instances ---\n'
gcloud compute instances list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,status,zone)' 2>&1 || true
printf '\n--- Persistent Disks ---\n'
gcloud compute disks list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,sizeGb,zone,status)' 2>&1 || true
printf '\n--- VPC networks ---\n'
gcloud compute networks list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,subnetMode,autoCreateSubnetworks)' 2>&1 || true
printf '\n--- Firewall rules ---\n'
gcloud compute firewall-rules list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,network,direction,priority)' 2>&1 || true
printf '\n--- Cloud Storage buckets ---\n'
gcloud storage buckets list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,location,storageClass)' 2>&1 || true
printf '\n--- Cloud SQL instances ---\n'
gcloud sql instances list --project="$DAY5_INVENTORY_PROJECT" --format='table(name,region,state)' 2>&1 || true
printf '\n--- Service accounts ---\n'
gcloud iam service-accounts list --project="$DAY5_INVENTORY_PROJECT" --format='table(email,displayName,disabled)' 2>&1 || true

cat <<'EOF2'

Review the inventory against the actual Day 5 names from its outputs and Console screenshots.
Also inspect IAM & Admin -> Roles and IAM & Admin -> Deny policies for the exact Day 5 custom role/policy.
Do not treat enabled APIs as stale lab resources; do not disable APIs during this handoff.
EOF2

read -r -p "After you have confirmed Day 5 destroy and checked the inventory, type CLEAN to authorize the Day 6 preflight gate: " ACK
if [[ "$ACK" != "CLEAN" ]]; then
  echo "Not confirmed. No marker written; do not proceed to Day 6 terraform init."
  exit 6
fi

printf '%s\n' "$ACTIVE_PROJECT" > "$DAY6_ROOT/.day5-transition-cleared"
printf 'Verified by operator at %s\n' "$(date -Is)" >> "$DAY6_ROOT/.day5-transition-cleared"
echo "Transition acknowledgement recorded for project $ACTIVE_PROJECT. Continue with scripts/00-preflight.sh."
