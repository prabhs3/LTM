# GCP Day 6 - Student-Ready Terraform Package

This is the cleaned, single-root Terraform package for the GCP Day 6 Cloud Shell lab. All `.tf` files, `terraform.tfvars.example`, and `scripts/` are at this package root. Do not enter an older nested copy of this package.

## Start here
1. **Close Day 5 first.** Follow `DAY5_TO_DAY6_HANDOFF.md` from the original `~/gcp-day5-lab` directory, inspect and apply its reviewed destroy plan, and verify no Day 5 managed resources remain. Do not run `rm -rf` or copy Day 5 state/cache files.
2. Use an existing, disposable, billed GCP training project. This Terraform stack does not create or delete the project.
3. Upload this ZIP to Google Cloud Shell and extract it into `~/gcp-day6-lab`. If this folder already has `.terraform/` or state files, stop and inspect the previous Day 6 attempt; do not overwrite it.
4. Run `cd ~/gcp-day6-lab` and confirm `main.tf`, `variables.tf`, `versions.tf`, `outputs.tf`, and `terraform.tfvars.example` are all in the current directory.
5. Copy `terraform.tfvars.example` to `terraform.tfvars`; set the same `project_id` as the active `gcloud` project, enter `operator_email`, set `alert_email` only if needed, and choose a unique `name_prefix` such as `d6-s01` if students share a project. Preserve all fault toggles.
6. Run `./scripts/00-day5-transition-check.sh`; review its inventory and type `CLEAN` only after manual confirmation. Then run `./scripts/00-preflight.sh`.
7. Run `terraform fmt -recursive`, `terraform init`, `terraform validate`, `terraform plan`, inspect the plan, and only then apply.
8. Follow `GCP_Day6_Final_Student_Lab_Execution_Guide.docx` / PDF for objectives, explanation, CLI proof and Console GUI checks.

## Package contents
- `DAY5_TO_DAY6_HANDOFF.md` - Day 5 teardown, stale-resource inventory and Day 6 state isolation
- `scripts/00-day5-transition-check.sh` - read-only transition gate; does not delete resources
- `versions.tf`, `variables.tf`, `main.tf`, `network_nat.tf`, `storage_security.tf`, `monitoring.tf`, `outputs.tf`
- `terraform.tfvars.example`
- `scripts/00-preflight.sh`, `scripts/10-outputs.sh`
- `.gitignore` and `CLOUDSHELL_RUNBOOK.md`

## State and naming isolation
Day 5 and Day 6 must use separate working directories and state. Day 6 defaults to `name_prefix = "d6"`, which is combined with the first eight characters of the project ID for most resource names. Use a different short prefix (maximum 10 characters) per student when several students share a project. Shared APIs may remain enabled after Day 5 destroy; do not manually disable them.

## Safe defaults
No public VM IP addresses. Cloud NAT, temporary public bucket access, CMEK, alerting, firewall Deny, and IAM Deny are opt-in. Only synthetic content is used. The signed-in operator must already be authorized to run the initial Terraform apply. Do not publish `.tfstate`, `.tfplan`, `.tfvars`, credentials, or the `.terraform/` directory. Keep `.terraform.lock.hcl` after initialization.

## Validation boundary
The authoring environment performed static checks and shell syntax checks only. It did not have Terraform CLI or credentials to execute `terraform init`, `terraform validate`, a project-specific plan, or live GCP apply. Perform those checks in the target Cloud Shell and review every plan.
