variable "project_id" {
  description = "Existing billed Google Cloud project ID. Terraform does not create projects."
  type        = string

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{4,28}[a-z0-9]$", var.project_id))
    error_message = "project_id must be a valid Google Cloud project ID: 6-30 lowercase letters, digits or hyphens, starting with a letter and ending with a letter or digit."
  }
}

variable "name_prefix" {
  description = "Short lowercase prefix used for lab resource names. Change it for each parallel class."
  type        = string
  default     = "d6"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{0,9}$", var.name_prefix))
    error_message = "name_prefix must start with a lowercase letter and contain only lowercase letters, digits, or hyphens (max 10 characters)."
  }
}

variable "region" {
  description = "GCP region for the VPC, subnet, Cloud NAT, bucket, and optional KMS key."
  type        = string
  default     = "us-central1"
}

variable "zone" {
  description = "GCP zone for the lab VMs, disk, and zonal Managed Instance Group."
  type        = string
  default     = "us-central1-a"

  validation {
    condition     = can(regex("^[a-z]+-[a-z]+[0-9]-[a-z]$", var.zone))
    error_message = "zone must use a valid zone format such as us-central1-a; also ensure it belongs to the selected region."
  }
}

variable "subnet_cidr" {
  description = "Private IPv4 range for the isolated Day 6 subnet."
  type        = string
  default     = "10.60.0.0/24"
}

variable "machine_type" {
  description = "Small machine type for the lab VMs and MIG. Check current regional availability and pricing."
  type        = string
  default     = "e2-micro"
}

variable "data_disk_size_gb" {
  description = "Size of the attached data disk on the storage VM. Increase this value to demonstrate a disk resize."
  type        = number
  default     = 10

  validation {
    condition     = var.data_disk_size_gb >= 10 && var.data_disk_size_gb <= 100 && var.data_disk_size_gb == floor(var.data_disk_size_gb)
    error_message = "For this lab, data_disk_size_gb must be between 10 and 100 GB."
  }
}

variable "mig_target_size" {
  description = "Desired size of the zonal Managed Instance Group. Default is 2; set to 4 for scale-out."
  type        = number
  default     = 2

  validation {
    condition     = var.mig_target_size >= 1 && var.mig_target_size <= 4 && var.mig_target_size == floor(var.mig_target_size)
    error_message = "mig_target_size must be between 1 and 4 for this training lab."
  }
}

variable "operator_email" {
  description = "Optional signed-in operator email. When set, Terraform grants the read-only/OS Login/IAP roles needed for this lab and Token Creator on the test identity."
  type        = string
  default     = ""

  validation {
    condition     = var.operator_email == "" || can(regex("^[^@ ]+@[^@ ]+\\.[^@ ]+$", var.operator_email))
    error_message = "operator_email must be blank or a valid email address."
  }
}

variable "alert_email" {
  description = "Required only when enable_cpu_alert=true. Use a monitored training mailbox that can receive the alert."
  type        = string
  default     = ""
}

variable "enable_cloud_nat" {
  description = "Create Cloud Router and Cloud NAT to provide outbound internet access to private VMs. NAT is billable."
  type        = bool
  default     = false
}

variable "enable_public_bucket_fault" {
  description = "Temporarily add allUsers objectViewer to the synthetic lab bucket. Use only in an isolated disposable project and only if organization policy permits."
  type        = bool
  default     = false
}

variable "enable_cmek" {
  description = "Create a Cloud KMS key and apply it as the Cloud Storage bucket default encryption key. New objects uploaded after the change use the CMEK."
  type        = bool
  default     = false
}

variable "enable_cpu_alert" {
  description = "Create a CPU alert policy and email notification channel. Requires alert_email."
  type        = bool
  default     = false
}

variable "enable_firewall_deny" {
  description = "Inject a higher-priority IAP SSH deny rule for the capstone war-room exercise."
  type        = bool
  default     = false
}

variable "enable_iam_deny_fault" {
  description = "Inject a project-level IAM Deny policy against the dedicated responder test service account only. The signed-in operator remains unaffected."
  type        = bool
  default     = false
}

variable "ssh_vm_fixed" {
  description = "Set true after the SSH diagnostic to remediate the broken VM by adding the IAP firewall target tag through Terraform (avoids out-of-band drift)."
  type        = bool
  default     = false
}

variable "enable_responder_allow" {
  description = "Keep the synthetic responder service account's Compute Viewer Allow. Set false only for the no-organization-access capstone fallback; this removes the Allow but is not an IAM Deny policy proof."
  type        = bool
  default     = true
}
