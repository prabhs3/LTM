resource "google_compute_router" "nat" {
  count       = var.enable_cloud_nat ? 1 : 0
  name        = "${local.prefix}-router"
  project     = var.project_id
  region      = var.region
  network     = google_compute_network.lab.id
  description = "Day 6 egress restoration exercise - Cloud Router."
  bgp {
    asn = 64514
  }
}

resource "google_compute_router_nat" "nat" {
  count                              = var.enable_cloud_nat ? 1 : 0
  name                               = "${local.prefix}-nat"
  project                            = var.project_id
  router                             = google_compute_router.nat[0].name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  auto_network_tier                  = "PREMIUM"

  log_config {
    enable = true
    filter = "ERRORS_ONLY"
  }
}
