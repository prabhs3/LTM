# GCP Day 6 Lab - Cloud Shell + Terraform Runbook

**Program:** Multi-Cloud Foundations Bootcamp - Day 6 (GCP)  
**Delivery:** Google Cloud Shell (Bash) + Terraform  
**Lab duration from source brief:** 4 hours theory + 4 hours practical (8 hours total)  
**Scope:** GCP-INC-2001, GCP-INC-2002, GCP-INC-2003, cross-provider equivalence matrix, integrated four-fault war room, formal PIR.

---

## 0. Mandatory transition from Day 5

**Do not start Day 6 from the Day 5 working directory.** Day 5 uses `~/gcp-day5-lab`; Day 6 uses `~/gcp-day6-lab`. Each root directory has its own Terraform configuration, initialization metadata and state. The Day 5 guide says resource names/bucket names are generated, so students must use the Day 5 outputs captured before destroy and must not guess names. The Day 5 Terraform ZIP/configuration was not included with this revision, so the handoff check cannot assert every Day 5 resource by a fixed name; the original Day 5 state, outputs and Console inventory remain authoritative.

Before Day 6 upload/init, close Day 5 from its original directory and exact backend/workspace:

```bash
cd "$HOME/gcp-day5-lab"
pwd
gcloud config get-value project
terraform workspace list
terraform workspace show
terraform output
terraform state list
terraform plan -destroy -out=day5-destroy.tfplan
terraform show day5-destroy.tfplan
```

Review that plan for the Day 5 project and Day 5 lab resources only. Turn off optional Day 5 services first (for example, `enable_cloud_sql=false`, `enable_iam_deny_policy=false`, and `secondary_project_id=""` where those exact variables exist in the Day 5 package). Review any organization-level Deny policy by its exact name and scope; do not remove shared policies. If the plan is correct, run:

```bash
terraform apply day5-destroy.tfplan
terraform state list
```

Then compare the Day 5 inventory captured from `terraform output` with the project inventory in Console/CLI. Keep `gcloud` pointed at the Day 5 project for this check. If Day 6 uses a different project, switch to the Day 6 project only after Day 5 verification: Compute Engine instances/disks, VPC networks/firewalls, Cloud Storage buckets, Cloud SQL instances, service accounts, custom IAM roles, and Deny policies. Remove a leftover only through the Day 5 owning state or an instructor-approved manual process.

**Enabled APIs are not stale lab infrastructure by themselves.** Do not manually disable APIs as part of the handoff; Day 6 needs some of the same APIs.

Now upload/extract Day 6 into a separate folder. Do not copy `.terraform/`, `terraform.tfstate*`, plans, `terraform.tfvars`, or the Day 5 provider lock file. If `~/gcp-day6-lab` already contains `.terraform/` or state files, stop and inspect that earlier Day 6 attempt rather than overwriting it.

Create `terraform.tfvars` from the example first and set `project_id` to the same project selected by `gcloud config get-value project`. Set a unique `name_prefix` if students share a project. Run the read-only handoff gate and inspect the inventory it prints:

```bash
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars
./scripts/00-day5-transition-check.sh
```

Type `CLEAN` only after confirming Day 5 resources are gone (or explicitly approved leftovers are documented). The script writes a project-specific `.day5-transition-cleared` marker and never destroys resources. Then run `./scripts/00-preflight.sh`. If Day 5 used a different folder or backend, set `DAY5_DIR=/exact/day5/path` before running the gate. If Day 5 used additional Terraform workspaces, inspect and destroy each intended lab workspace separately; the gate stops when it detects non-default workspaces.

Day 6 defaults to `name_prefix="d6"`; most resources use `d6-<first-eight-project-id-characters>`, and the bucket uses the prefix plus the full project ID. For multiple students sharing one project, assign unique prefixes such as `d6-s01`, `d6-s02` (maximum 10 lowercase alphanumeric/hyphen characters). If a Day 6-prefixed resource exists but the Day 6 state is missing, stop and recover the correct Day 6 state or import only after exact identity/configuration review. Do not import a Day 5 resource merely because it exists.

---

## 1. Purpose and source alignment

This runbook implements the ten-page Techademy Day 6 brief. It preserves the source scenario structure:

| Source scenario | Required proof |
|---|---|
| GCP-INC-2001 - Compute lifecycle and connectivity | Stop an idle VM, troubleshoot SSH to a new VM, scale a Managed Instance Group from 2 to 4. |
| GCP-INC-2002 - Storage and networking bundle | Fill a Persistent Disk, resize it, remove public access from a synthetic Cloud Storage bucket, restore private-VM egress with Cloud NAT. |
| GCP-INC-2003 - Encryption, secrets and alerting | Configure CMEK for a Cloud Storage bucket, rotate a synthetic Secret Manager value, rebuild and trigger a Cloud Monitoring alert. |
| Cross-provider capstone | Compare Azure, AWS and GCP service equivalents and document gaps instead of assuming 1:1 equivalence. |
| PIR-D6 - Go-live war room | Triage identity deny, firewall block, full disk and missing alert; produce a formal Post-Incident Review. |

The source PDF does not provide a Terraform package, fixed resource names, an operator email, or the course outcome definitions for CO-01...CO-11 / EO-01...EO-05. This package supplies a training implementation and leaves outcome mapping for the instructor/student to complete.

## 2. Important implementation decisions and safety boundaries

1. **Existing project only.** Terraform does not create or delete the GCP project. Use a dedicated billed training project, never production.
2. **Cloud Shell authentication.** Cloud Shell already provides credentials to Application Default Credentials (ADC); do not create or download service-account JSON keys.
3. **No public IPs.** VMs have no external IPv4 address. SSH is intended to use IAP TCP forwarding and OS Login.
4. **Minimal first apply.** Cloud NAT, the temporary public bucket binding, CMEK, the alert, firewall deny and IAM Deny are disabled by default. Enable them only for their relevant exercise.
5. **Synthetic data only.** The bucket object and password examples are synthetic. Do not upload regulated, customer, or real credential data.
6. **Public bucket fault is opt-in.** `enable_public_bucket_fault=true` temporarily grants `allUsers` objectViewer on a dedicated synthetic bucket. Use it only in a disposable project, only with non-sensitive data, and only if organization policy permits public access. The fault must be removed immediately after proof.
7. **IAM Deny never targets the signed-in student.** It targets a dedicated synthetic responder service account. The student/operator retains control-plane access to remediate the exercise.
8. **CMEK is protected.** The CryptoKey Terraform resource uses `prevent_destroy=true`. When CMEK is enabled, the final `terraform destroy` is intentionally blocked until the instructor has reviewed and deliberately handled the key lifecycle. Do not remove the protection casually. See Section 12.
9. **Cloud NAT is billable.** Keep it disabled outside the egress exercise. Cloud NAT and its data processing can incur charges; stop the lab after evidence collection.
10. **Terraform state is sensitive.** Keep the lab folder and state private. Do not upload state, plans, or local tfvars to a public repository.

### Source wording clarification: encryption

The source slide calls this fault "unencrypted regulated data." Google Cloud encrypts customer content at rest by default using Google-managed encryption. The meaningful governance exercise is to add and verify **customer-managed encryption keys (CMEK)**, not to imply that Cloud Storage stores ordinary data in plaintext at rest. CMEK gives the customer more control over key lifecycle, rotation and audit.

## 3. Architecture deployed

| Component | Resource | Default state | Purpose |
|---|---|---|---|
| Existing project | Existing project ID | Required | Terraform deploy target; no project creation. |
| Network | Custom VPC + subnet | Created | Isolated private network. |
| VM - idle | Compute Engine VM | Created, no external IP | Stop/start and billing lifecycle exercise. |
| VM - SSH broken | Compute Engine VM | Created without IAP SSH target tag | Deliberately fail SSH, then add the target tag. |
| VM - storage | Compute Engine VM + attached Persistent Disk | Created | Disk-full, disk resize, SSH, CPU-alert exercises. |
| MIG | Zonal Managed Instance Group | 2 instances | Scale 2 -> 4 and verify healthy member count. |
| Cloud Storage | Bucket + synthetic text object | Private | Public exposure and lockdown demonstration. |
| Cloud NAT | Cloud Router + NAT | Disabled | Enable temporarily for egress restoration. |
| KMS | Key ring + CryptoKey | Disabled | Enable only for the CMEK exercise. |
| Secret Manager | Secret metadata | Created; no secret value in Terraform | Add and rotate synthetic versions through gcloud. |
| Monitoring | Email channel + CPU alert | Disabled | Rebuild and trigger alert. |
| IAM | Responder test service account | Created with Compute Viewer Allow | Target for optional project-level IAM Deny proof. |
| Firewall deny | Higher-priority IAP SSH deny rule | Disabled | Inject and remove the capstone SSH fault. |

### Design view

```text
Existing billed GCP project
  |
  +-- Custom VPC / regional subnet (private Google access)
  |     |
  |     +-- VM: idle (IAP SSH)
  |     +-- VM: ssh-broken (no IAP target tag until fixed)
  |     +-- VM: storage ---- attached data Persistent Disk
  |     +-- Zonal MIG: 2 Debian instances (scale to 4)
  |     +-- Optional Cloud Router + Cloud NAT (egress)
  |
  +-- Cloud Storage bucket + synthetic object (private by default)
  +-- Optional Cloud KMS key (CMEK)
  +-- Secret Manager secret metadata (versions added outside Terraform)
  +-- Optional Cloud Monitoring email channel + CPU alert
  +-- Responder service account (Viewer Allow; optional IAM Deny)
```

## 4. Prerequisites and required permissions

- Existing Google Cloud project with billing enabled.
- Project permissions to enable APIs and create Compute Engine instances/disks/MIGs, VPC/firewall, Cloud Storage bucket/IAM, service accounts/IAM, Secret Manager, Monitoring, Cloud NAT and (for the optional Deny) IAM Deny policies.
- For IAP SSH: IAP tunnel access, OS Login access and permission to act as the VM runtime service account. The Terraform package can create the helper bindings when `operator_email` is populated.
- For alerting: permission to create notification channels and alert policies; a monitored email address in `alert_email`.
- For CMEK: Cloud KMS key administration and permission to grant the Cloud Storage service agent the `roles/cloudkms.cryptoKeyEncrypterDecrypter` role.
- For public bucket fault: project/organization policy must permit a temporary `allUsers` binding. If public access prevention is enforced, do not bypass it; record the policy enforcement as the security result.
- For IAM Deny: project-level policy administration must be available and `compute.googleapis.com/instances.get` must be supported for Deny in the project. The IAM Deny resource is used through the GA Google provider resource.

### Verify access before uploading the package

In Cloud Shell:

```bash
gcloud auth list
gcloud config get-value project
PROJECT_ID="$(gcloud config get-value project 2>/dev/null)"
gcloud projects describe "$PROJECT_ID" --format="table(projectId,name,lifecycleState)"
gcloud billing projects describe "$PROJECT_ID" --format="yaml(projectId,billingEnabled)"
```

Confirm the project ID and billing status. If needed:

```bash
gcloud config set project YOUR_EXISTING_PROJECT_ID
```

Do not proceed if the active project is not the allocated training project.

## 5. Upload and configure the Terraform package in Cloud Shell

1. Download `GCP_Day6_Terraform_Lab_Package.zip` from the training materials.
2. Open Google Cloud Console and activate **Cloud Shell** (Bash).
3. In Cloud Shell, choose **Manage files -> Upload** and upload the ZIP to your home directory.
4. Extract and enter the folder:

```bash
mkdir -p "$HOME/gcp-day6-lab"
unzip -o "$HOME/GCP_Day6_Terraform_Lab_Package.zip" -d "$HOME/gcp-day6-lab"
cd "$HOME/gcp-day6-lab"
ls -la
```

5. Check Terraform:

```bash
terraform version
```

This package requires Terraform **1.5.7 or later** and pins the Google provider to **8.8.1**. If Terraform is missing, install it using Google's current Terraform-on-Cloud-Shell instructions before continuing. Do not paste installation commands into `.tf` files.

Before Terraform initialization, bootstrap the Service Usage API (Terraform uses this API to enable the remaining APIs):

```bash
PROJECT_ID="$(gcloud config get-value project 2>/dev/null)"
gcloud services enable serviceusage.googleapis.com cloudresourcemanager.googleapis.com --project="$PROJECT_ID"
```

The Cloud Shell operator should have **Project Owner** on this disposable training project, or an approved equivalent covering API enablement, service accounts, IAM policy updates, Compute Engine, VPC/firewall, Cloud Storage, Secret Manager, Cloud KMS and Monitoring. Do not use a production project. When `operator_email` is populated, Terraform also assigns operational roles to that user for the lab; this does not replace the permissions needed by the identity running the initial Terraform apply.

For the live project-level IAM Deny fault, an organization administrator must separately grant the operator `roles/iam.denyAdmin` at the organization scope. Google documents this role as organization-scoped; it is not part of the project-level role grants in this package. If that access is unavailable, the capstone can use the included fallback of removing the responder service account's `roles/compute.viewer` Allow. That proves an identity access failure, **not** IAM Deny precedence. Alternatively use an instructor-approved policy simulator and label it simulator-only.

6. Create your local tfvars file:

```bash
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars
```

Set at least the existing project ID. Strongly recommended: set `operator_email` to the exact account shown by `gcloud auth list`; this enables the operational helper grants and resource-scoped roles used by the CLI exercises.

```hcl
project_id     = "YOUR_EXISTING_PROJECT_ID"
operator_email = "YOUR_SIGNED_IN_GOOGLE_ACCOUNT_EMAIL"
```

Keep the fault toggles `false` and `ssh_vm_fixed=false` for the initial deployment. Save with Ctrl+O, Enter, Ctrl+X.

When `operator_email` is set, the package grants only this lab operator the roles required for the exercises: Compute Instance Admin, Compute Network Admin, Compute Security Admin, OS Login, IAP Tunnel Access, Monitoring Editor, Cloud KMS Admin, Service Usage Admin, and scoped Service Account User / Storage Admin / Secret Version Manager grants. The Terraform runner must already be authorized to create these IAM bindings. The organization-level `roles/iam.denyAdmin` grant is deliberately excluded and must be provided separately by an organization administrator for the live Deny scenario.

## 6. Validate and deploy the baseline

Run each command in sequence. Review the plan before applying:

```bash
terraform fmt -recursive
terraform init
terraform validate
terraform plan -out=day6-baseline.tfplan
terraform show day6-baseline.tfplan
```

**Keep the generated `.terraform.lock.hcl` file.** It records the selected provider build and checksums for repeatable installs. Do not add it to `.gitignore`; retain it with the lab source when you reuse or distribute the package. The `.terraform/` working directory, state, plans and local `terraform.tfvars` remain private and excluded from source control.

The baseline should create:
- custom VPC/subnet and the IAP SSH allow rule;
- three small private VMs (the SSH-broken VM intentionally has no IAP target tag);
- one small data disk attached to the storage VM;
- one zonal MIG with two instances;
- one private synthetic Cloud Storage bucket and sample object;
- runtime and responder service accounts, the responder's Compute Viewer Allow, and optional operator access bindings;
- a private Secret Manager secret with no secret version/value; if `operator_email` is set, a secret-scoped Secret Version Manager role;
- if `operator_email` is set, Compute Instance Admin, Network Admin, Security Admin, OS Login, IAP and Monitoring helper roles, plus bucket-scoped Storage Admin and a service-account-scoped Service Account User grant.

The baseline should **not** create Cloud NAT, the CMEK key, the public bucket binding, the CPU alert, the firewall Deny rule or the IAM Deny policy. The responder service account's `roles/compute.viewer` Allow remains present for the optional Deny-precedence test.

If the plan targets any resource outside the dedicated Day 6 naming prefix/project, stop and investigate.

Apply:

```bash
terraform apply day6-baseline.tfplan
terraform output
terraform state list
```

Record outputs; do not copy example IDs or names. The bucket name uses the project ID to reduce global name collisions.

## 7. One-time storage VM disk preparation

Connect to the storage VM (use the output value):

```bash
VM_STORAGE="$(terraform output -raw vm_storage_name)"
ZONE="$(terraform output -raw zone)"
PROJECT_ID="$(terraform output -raw project_id)"
gcloud compute ssh "$VM_STORAGE" --project="$PROJECT_ID" --zone="$ZONE" --tunnel-through-iap
```

Inside the VM, identify the attached disk and format it once:

```bash
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINT
sudo mkfs.ext4 -F /dev/disk/by-id/google-d6-data-disk
sudo mkdir -p /mnt/d6data
sudo mount /dev/disk/by-id/google-d6-data-disk /mnt/d6data
sudo chown "$USER":"$USER" /mnt/d6data
df -h /mnt/d6data
```

For persistence across VM restarts, add a UUID-based fstab entry:

```bash
DISK_UUID="$(sudo blkid -s UUID -o value /dev/disk/by-id/google-d6-data-disk)"
echo "UUID=$DISK_UUID /mnt/d6data ext4 defaults,nofail 0 2" | sudo tee -a /etc/fstab
```

Do not run `mkfs` again after the disk contains data. Formatting destroys its contents.

## 8. GCP-INC-2001 - Compute lifecycle and connectivity

### 8.1 Stop an idle but running VM

```bash
VM_IDLE="$(terraform output -raw vm_idle_name)"
gcloud compute instances describe "$VM_IDLE" --zone="$ZONE" --project="$PROJECT_ID" --format="table(name,status,machineType,zone)"
gcloud compute instances stop "$VM_IDLE" --zone="$ZONE" --project="$PROJECT_ID"
gcloud compute instances describe "$VM_IDLE" --zone="$ZONE" --project="$PROJECT_ID" --format="table(name,status)"
```

**Evidence:** capture the pre-stop RUNNING state and post-stop TERMINATED state. Explain that stopping the VM stops guest compute consumption, but attached persistent disks and reserved resources may continue to incur charges. Start it again if required:

```bash
gcloud compute instances start "$VM_IDLE" --zone="$ZONE" --project="$PROJECT_ID"
```

### 8.2 Troubleshoot the deliberately broken SSH VM

The second VM has no `d6-iap-ssh` network tag, so the IAP firewall allow rule does not target it. The VM has no external IP by design.

```bash
VM_SSH="$(terraform output -raw vm_ssh_broken_name)"
gcloud compute instances describe "$VM_SSH" --zone="$ZONE" --project="$PROJECT_ID" --format="yaml(name,status,tags.items,networkInterfaces)"
```

Attempt SSH and capture the failure:

```bash
gcloud compute ssh "$VM_SSH" --zone="$ZONE" --project="$PROJECT_ID" --tunnel-through-iap
```

Remediate through Terraform so the fix is recorded in state and is not undone by a later apply. Set `ssh_vm_fixed = true` in `terraform.tfvars`, then:

```bash
terraform plan -out=day6-ssh-remediation.tfplan
terraform show day6-ssh-remediation.tfplan
terraform apply day6-ssh-remediation.tfplan
gcloud compute instances describe "$VM_SSH" --zone="$ZONE" --project="$PROJECT_ID" --format="yaml(name,tags.items)"
gcloud compute ssh "$VM_SSH" --zone="$ZONE" --project="$PROJECT_ID" --tunnel-through-iap
```

Avoid an out-of-band `gcloud compute instances add-tags` fix: Terraform owns the instance tags and would detect drift on a later apply.

**Diagnostic order (source brief):** check external IP / chosen connection method, firewall rule and target tags, then SSH identity/OS Login permissions. This package intentionally uses IAP with no external IP, so students should not add a public IP as the first fix.

### 8.3 Generate a workload signal and scale the Managed Instance Group from 2 to 4

The source brief describes scaling under load. This Terraform stack provisions a fixed-size zonal MIG; the scale decision is a manual operations action (not an autoscaler policy). To generate a safe, time-boxed CPU workload, first list the managed members and connect to one (the MIG template includes the IAP SSH tag):

```bash
MIG="$(terraform output -raw mig_name)"
MIG_VM_URI="$(gcloud compute instance-groups managed list-instances "$MIG" --zone="$ZONE" --project="$PROJECT_ID" --format='value(instance)' | head -n1)"
MIG_VM="${MIG_VM_URI##*/}"
gcloud compute ssh "$MIG_VM" --zone="$ZONE" --project="$PROJECT_ID" --tunnel-through-iap
```

Inside the MIG VM, run a bounded CPU test using the Python 3 runtime available on Debian images:

```bash
python3 - <<'PYTHON'
import multiprocessing, time

def burn(seconds):
    end = time.time() + seconds
    value = 0
    while time.time() < end:
        value = (value + 1) % 1000003

workers = [multiprocessing.Process(target=burn, args=(90,)) for _ in range(2)]
for worker in workers:
    worker.start()
for worker in workers:
    worker.join()
print("90-second training load test completed")
PYTHON
```

Exit back to Cloud Shell, inspect CPU metrics in **Monitoring -> Metrics Explorer**, then scale the managed group in response to the observed synthetic load:

```bash
MIG="$(terraform output -raw mig_name)"
gcloud compute instance-groups managed describe "$MIG" --zone="$ZONE" --project="$PROJECT_ID" --format="yaml(name,targetSize,status)"
gcloud compute instance-groups managed resize "$MIG" --size=4 --zone="$ZONE" --project="$PROJECT_ID"
gcloud compute instance-groups managed list-instances "$MIG" --zone="$ZONE" --project="$PROJECT_ID" --format="table(instance,status)"
```

**Evidence:** target size and four managed members, with each member's status. The CLI resize is an operational demonstration and creates Terraform drift because `mig_target_size` remains 2 in `terraform.tfvars`. To restore the baseline before another Terraform apply, resize back to 2 or change `mig_target_size` to 4 and apply. Do not accidentally reconcile the group back to 2 while collecting scale-out evidence.

## 9. GCP-INC-2002 - Storage and networking bundle

### 9.1 Fill the attached Persistent Disk (synthetic data only)

From the storage VM:

```bash
sudo dd if=/dev/zero of=/mnt/d6data/fill.bin bs=16M status=progress
```

The command is expected to stop with `No space left on device`. Capture:

```bash
df -h /mnt/d6data
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT
```

This consumes only the dedicated 10 GB lab disk. Do not fill the boot disk or a production filesystem.

### 9.2 Resize the Persistent Disk with Terraform, then grow the in-guest filesystem

Exit SSH. In Cloud Shell edit `terraform.tfvars` and change:

```hcl
data_disk_size_gb = 20
```

Then:

```bash
terraform plan -out=day6-disk-resize.tfplan
terraform show day6-disk-resize.tfplan
terraform apply day6-disk-resize.tfplan
```

Reconnect to the storage VM. For ext4 created directly on the whole device, grow the filesystem after the cloud disk size has increased:

```bash
sudo resize2fs /dev/disk/by-id/google-d6-data-disk
df -h /mnt/d6data
lsblk -o NAME,SIZE,FSTYPE,MOUNTPOINT
```

Verify the block-device size and filesystem size. Remove the synthetic fill file after collecting proof:

```bash
sudo rm -f /mnt/d6data/fill.bin
df -h /mnt/d6data
```

Do not reduce a Persistent Disk size; the exercise is an expansion.

### 9.3 Prove temporary public exposure, then lock down the bucket

The Terraform baseline bucket is private. Only for the controlled fault demonstration, edit `terraform.tfvars`:

```hcl
enable_public_bucket_fault = true
```

Review and apply:

```bash
terraform plan -out=day6-public-fault.tfplan
terraform show day6-public-fault.tfplan
terraform apply day6-public-fault.tfplan
```

Get the bucket and object URI:

```bash
BUCKET="$(terraform output -raw bucket_name)"
OBJ="$(terraform output -raw sample_object_uri)"
curl -I "https://storage.googleapis.com/${BUCKET}/internal-reports/day6-synthetic-report.txt"
gcloud storage buckets get-iam-policy "gs://${BUCKET}"
```

If public access is permitted, the unauthenticated request should return a successful response. Now remediate immediately:

Set `enable_public_bucket_fault = false`, then:

```bash
terraform plan -out=day6-bucket-lockdown.tfplan
terraform show day6-bucket-lockdown.tfplan
terraform apply day6-bucket-lockdown.tfplan
curl -I "https://storage.googleapis.com/${BUCKET}/internal-reports/day6-synthetic-report.txt"
gcloud storage buckets get-iam-policy "gs://${BUCKET}"
```

Expected: public read is denied (typically HTTP 403) and `allUsers` is absent from the bucket IAM policy. Capture the live 403 as the evidence; a config change alone is not proof.

**Organization-policy fallback:** if Public Access Prevention is enforced and Terraform cannot add `allUsers`, do not weaken the organization policy. Capture the policy/result, prove that unauthenticated access is denied, and label the exercise "public access prevented by policy" rather than claiming a successful exposure/removal cycle.

### 9.4 Demonstrate lost egress and restore it with Cloud NAT

Before enabling NAT, from the storage VM:

```bash
curl -I --connect-timeout 8 --max-time 12 https://example.com
```

With no external VM IP and no Cloud NAT, this should fail to establish general internet egress (assuming no alternate egress path is supplied by the training organization).

In `terraform.tfvars` set:

```hcl
enable_cloud_nat = true
```

Review and apply:

```bash
terraform plan -out=day6-nat-enable.tfplan
terraform show day6-nat-enable.tfplan
terraform apply day6-nat-enable.tfplan
```

Repeat from the VM:

```bash
curl -I --connect-timeout 10 --max-time 20 https://example.com
```

Expected: an HTTP response from the test endpoint. Verify Cloud NAT and router in Console or with:

```bash
REGION="$(terraform output -raw region)"
ROUTER="$(terraform output -raw nat_router_name)"
gcloud compute routers list --regions="$REGION" --project="$PROJECT_ID"
gcloud compute routers nats list --router="$ROUTER" --region="$REGION" --project="$PROJECT_ID"
```

`PREFIX` can be derived from the Terraform resources shown in `terraform state list` or the router name in Console. If the request still fails, check the default route, egress firewall policy, NAT subnet coverage and NAT logs. Cloud NAT is billable; set `enable_cloud_nat=false` and apply after evidence collection if this class does not need it further.

## 10. GCP-INC-2003 - Encryption, secrets and alerting

### 10.1 Enable CMEK for Cloud Storage

**Concept clarification:** GCP encrypts Cloud Storage data at rest by default with Google-managed keys. CMEK adds customer control over key usage, rotation and access governance.

In `terraform.tfvars` set:

```hcl
enable_cmek = true
```

Review the plan carefully. It creates a KMS key ring/key, grants the Cloud Storage project service agent `roles/cloudkms.cryptoKeyEncrypterDecrypter`, and sets the bucket's default key. Apply:

```bash
terraform plan -out=day6-cmek.tfplan
terraform show day6-cmek.tfplan
terraform apply day6-cmek.tfplan
```

Upload a **new** synthetic object after CMEK is enabled (existing objects are not automatically re-encrypted merely because the bucket default key changed):

```bash
BUCKET="$(terraform output -raw bucket_name)"
printf 'DAY6 CMEK TEST ONLY - no regulated or customer data.\n' > /tmp/day6-cmek-sample.txt
gcloud storage cp /tmp/day6-cmek-sample.txt "gs://${BUCKET}/internal-reports/cmek-proof.txt"
gcloud storage buckets describe "gs://${BUCKET}" --format="yaml(name,encryption)"
gcloud storage objects describe "gs://${BUCKET}/internal-reports/cmek-proof.txt" --format="yaml"
```

**Evidence:** record the bucket default KMS key and the new object's KMS key. Review KMS key rotation schedule and version state in Cloud KMS. The 90-day rotation setting schedules rotation; it does not immediately rotate a key.

### 10.2 Create and rotate the synthetic database password in Secret Manager

Terraform created secret metadata only; secret payloads are intentionally excluded from Terraform state. Use synthetic values:

```bash
SECRET_ID="$(terraform output -raw secret_id)"
printf '%s' 'D6-TRAINING-ONLY-PASSWORD-V1' | gcloud secrets versions add "$SECRET_ID" --data-file=-
gcloud secrets versions list "$SECRET_ID"
```

Rotate by adding a new version:

```bash
printf '%s' 'D6-TRAINING-ONLY-PASSWORD-V2' | gcloud secrets versions add "$SECRET_ID" --data-file=-
gcloud secrets versions list "$SECRET_ID"
```

After verifying the application/test consumer uses the latest version, disable the old version:

```bash
gcloud secrets versions disable 1 --secret="$SECRET_ID"
gcloud secrets versions list "$SECRET_ID"
```

Do not put real passwords into `.tf`, `.tfvars`, shell scripts, screenshots or Git. Never use an actual production DB credential for the rotation demo. If a real credential was exposed in plaintext, rotate it at the source system as well as in Secret Manager.

### 10.3 Rebuild the CPU alert and prove the notification

Set a valid monitored mailbox in `terraform.tfvars` and enable the policy:

```hcl
alert_email      = "YOUR_MONITORED_EMAIL"
enable_cpu_alert = true
```

Apply:

```bash
terraform plan -out=day6-alert.tfplan
terraform show day6-alert.tfplan
terraform apply day6-alert.tfplan
```

Google Cloud may ask you to verify the email notification channel. Complete verification if prompted. Confirm the CRITICAL policy and channel in **Monitoring -> Alerting**.

To generate safe, temporary CPU load on the storage VM, use the shell's existing `yes` utility (no package download or Cloud NAT is required). Run this in the SSH session and allow it to complete:

```bash
yes > /dev/null & P1=$!
yes > /dev/null & P2=$!
sleep 180
kill "$P1" "$P2"
```

Wait for metric ingestion/evaluation, then confirm an incident appears and the notification reaches the configured mailbox. Compute Engine CPU metrics are sampled periodically and can take several minutes to appear; allow up to 4–5 minutes before concluding the alert failed. Capture the alert policy, incident and email. End the load test and confirm the incident closes after utilization falls below threshold.

If the VM is too small or the metric is delayed, capture the metric chart and adjust the test duration only; do not raise the threshold above the demonstrated signal. The lab alert is a practical demonstration, not a production SLO policy.

## 11. Capstone - Equivalence matrix and four-fault war room

### 11.1 Cross-provider equivalence matrix (from source Day 6 slide, page 6)

| Layer | Azure | AWS | GCP |
|---|---|---|---|
| Compute scale-out | VM Scale Set | Auto Scaling Group | Managed Instance Group |
| Load balancing | Azure Load Balancer | ELB / ALB | Cloud Load Balancing |
| Object storage | Blob Storage | S3 | Cloud Storage |
| Managed database | Azure SQL Database | RDS | Cloud SQL |
| IAM identity | Service Principal | IAM Role | Service Account |
| Monitoring | Azure Monitor | CloudWatch | Cloud Monitoring |

Do not treat these as perfect 1:1 equivalents. Document at least one configuration, identity, networking or operational difference for each row.

### 11.2 Inject all four faults in the isolated project

The source brief defines the simultaneous PIR-D6 faults as: identity Deny, firewall block, full disk and a silent/missing alert. Prepare them as follows:

1. **If organization-level Deny Admin is available:** set `enable_iam_deny_fault = true` and leave `enable_responder_allow = true` so the test proves an explicit Deny overrides an existing Allow. **If it is not available:** leave `enable_iam_deny_fault = false` and set `enable_responder_allow = false`; this fallback proves access removal, not Deny precedence.
2. Set `enable_firewall_deny = true`.
3. Set `enable_cpu_alert = false` (the alert is absent for the "silent alarm" fault).
4. Fill the dedicated data disk using the commands in Section 9.1 **before** enabling the firewall deny (because the firewall fault will block IAP SSH).
5. Keep `operator_email` configured so the operator can impersonate the dedicated responder identity and test the denied request. For a live project-scope IAM Deny, first confirm an organization administrator has granted the operator `roles/iam.denyAdmin` at the organization scope.

Review and apply:

```bash
terraform plan -out=day6-warroom-inject.tfplan
terraform show day6-warroom-inject.tfplan
terraform apply day6-warroom-inject.tfplan
```

Verify each fault independently:

**Fault A - identity deny:**

```bash
RESPONDER_SA="$(terraform output -raw responder_service_account)"
VM_IDLE="$(terraform output -raw vm_idle_name)"
gcloud --impersonate-service-account="$RESPONDER_SA" compute instances describe "$VM_IDLE" --zone="$ZONE" --project="$PROJECT_ID"
```

Expected: `PERMISSION_DENIED` for `compute.instances.get`. With the live Deny path, the responder SA still has the project-level `roles/compute.viewer` Allow, and the Deny overrides it. With the no-org fallback, the Allow was removed; label that evidence as role-removal, not Deny precedence. In both cases only the synthetic responder identity is affected.

**Fault B - firewall block:**

```bash
VM_STORAGE="$(terraform output -raw vm_storage_name)"
gcloud compute ssh "$VM_STORAGE" --zone="$ZONE" --project="$PROJECT_ID" --tunnel-through-iap
```

Expected: IAP SSH fails while the higher-priority deny rule is present. The student's gcloud/Console control plane remains available to remove the rule.

**Fault C - full disk:**

From a previously opened or reconnected storage VM session (before applying firewall deny, or after it is removed), verify:

```bash
df -h /mnt/d6data
```

Expected: the data filesystem is at/near 100% after the synthetic fill.

**Fault D - silent alert:**

```bash
gcloud monitoring policies list --project="$PROJECT_ID"
```

Expected: the Day 6 CPU alert is absent while `enable_cpu_alert=false`.

### 11.3 Triage in the source-defined order

The source Day 6 slide (page 7) specifies this priority order:

1. **Silent alarm -> restore visibility first.** Set `enable_cpu_alert=true` and a valid `alert_email`; apply and verify the policy/channel before moving on.
2. **Identity deny -> restore the engineer's test identity access.** For a live Deny path set `enable_iam_deny_fault=false`; for the role-removal fallback set `enable_responder_allow=true`. Apply. Re-run the exact impersonated `compute instances describe` command and confirm it succeeds.
3. **Firewall block -> restore connectivity to remediate.** Set `enable_firewall_deny=false`; apply. Re-run IAP SSH and confirm access works.
4. **Full disk -> extend storage last.** Set `data_disk_size_gb=20`; apply; reconnect and run `sudo resize2fs /dev/disk/by-id/google-d6-data-disk`; verify `df -h` shows free space.

Use separate reviewed plan/apply cycles if needed so the class can capture each recovery point. Do not use a single unreviewed `apply` as evidence of all four actions.

## 12. Cleanup and cost closure

### 12.1 Remove optional faults/services first

Set these values in `terraform.tfvars` and apply a reviewed plan:

```hcl
enable_public_bucket_fault = false
enable_cloud_nat           = false
enable_cpu_alert            = false
enable_firewall_deny        = false
enable_iam_deny_fault       = false
enable_responder_allow      = true
```

If CMEK was enabled, first delete the synthetic CMEK object and any other objects encrypted with the lab key (or deliberately retain the key and encrypted data under instructor control). Confirm no required data depends on the key. **Do not destroy a key version that protects data you intend to keep.**

### 12.2 Destroy disposable lab resources

For a baseline deployment where CMEK was never enabled:

```bash
terraform state list
terraform plan -destroy -out=day6-destroy.tfplan
terraform show day6-destroy.tfplan
```

Confirm the destroy plan contains only the Day 6 resources, then:

```bash
terraform apply day6-destroy.tfplan
```

If you prefer `terraform destroy`, review the interactive plan before typing `yes`.

### 12.3 CMEK lifecycle exception

The KMS CryptoKey resource has `prevent_destroy=true` because deleting/destroying a key version can make every object encrypted with that version unrecoverable. If `enable_cmek=true`, a full `terraform destroy` is expected to stop at this guard. This is intentional.

Instructor-controlled closeout:
- Identify every object protected by the key. Delete the synthetic objects or re-encrypt them to an independently managed key; confirm no production/shared data uses the lab key.
- **Retain the key:** first set `enable_cmek=false` in `terraform.tfvars`. Review `terraform state list`; the expected protected addresses are `google_kms_crypto_key.lab[0]` and `google_kms_key_ring.lab[0]`. Only after instructor approval, run `terraform state rm 'google_kms_crypto_key.lab[0]'` and `terraform state rm 'google_kms_key_ring.lab[0]'`. This intentionally leaves the KMS key/key ring in GCP but removes them from this lab's state; the instructor must record and manage them separately. The service-agent key binding, bucket and remaining lab resources can then be destroyed with the reviewed destroy plan.
- **Delete the key:** only after all dependent objects are deleted/re-encrypted and key-version consequences are reviewed, set `enable_cmek=false`, remove the `prevent_destroy` guard in a controlled code change, run `terraform plan -destroy`, inspect the exact KMS resources, and apply only after explicit instructor approval.
- Key rings/keys have lifecycle semantics different from ordinary disposable resources. Do not claim full cleanup while a key is intentionally retained.

### 12.4 Final verification

```bash
gcloud compute instances list --project="$PROJECT_ID"
gcloud compute disks list --project="$PROJECT_ID"
gcloud compute firewall-rules list --project="$PROJECT_ID"
gcloud storage buckets list --project="$PROJECT_ID"
gcloud compute routers list --regions="$REGION" --project="$PROJECT_ID"
gcloud monitoring policies list --project="$PROJECT_ID"
gcloud iam deny policies list --attachment-point="cloudresourcemanager.googleapis.com/projects/$PROJECT_ID"
```

Confirm no Day 6 VMs, attached data disk, NAT gateway, public bucket IAM member, alert, Deny policy or unused billable resources remain. A retained KMS key is an explicit exception to be documented.

## 13. Troubleshooting matrix

| Symptom | Check / action |
|---|---|
| `terraform` not found | Install current Terraform in Cloud Shell using Google's official instructions; verify `terraform version` before init. |
| API disabled | Confirm the active project and that the signed-in user can enable the required APIs. Re-run `terraform apply` after the API enablement operation completes. |
| Permission denied during apply | Check the exact missing permission and the corresponding IAM role; do not solve by granting Owner/Editor broadly to an identity. |
| IAP SSH fails | Confirm instance is RUNNING, the operator has IAP tunnel + OS Admin Login + Compute Viewer, operator can act as the VM runtime SA, tag `d6-iap-ssh` is present, allow rule exists, and no higher-priority deny is active. |
| SSH-broken VM remains inaccessible | Check the tag was added to the actual instance and that the allow rule targets `d6-iap-ssh`; retry via `--tunnel-through-iap`. |
| MIG does not show 4 instances | Check desired size, zone, quota, instance status and managed group operations; wait for group creation to finish. |
| Disk not visible in guest | Run `lsblk`; verify `google_compute_attached_disk` exists and the VM was restarted only if necessary. Confirm device name `d6-data-disk`. |
| `resize2fs` says device busy/not found | Confirm the disk is attached and mounted from `/dev/disk/by-id/google-d6-data-disk`; run `lsblk -f`; resize the filesystem only after the cloud disk is enlarged. |
| Public bucket binding rejected | Organization Policy/Public Access Prevention may block it. Do not bypass the policy; record the enforced-deny result. |
| CMEK bucket/object creation fails | Check Cloud KMS API, bucket location and key location compatibility, Storage service agent email, and CryptoKey Encrypter/Decrypter binding. Upload a new object only after permission propagation. |
| Secret add fails | Confirm Secret Manager API and `roles/secretmanager.secretVersionAdder` or equivalent permission; use `--data-file=-`; do not put payload into Terraform. |
| No alert notification | Check email channel verification, policy enabled state, metric filter, VM instance ID, threshold duration, metric ingestion delay, and recipient mailbox. |
| IAM Deny create fails | Check IAM Deny policy administration, Google provider initialization, supported permission list, exact parent resource and API enablement. The signed-in operator should not be in denied principals. |
| IAM Deny test is not denied | Confirm `roles/compute.viewer` Allow exists for the responder SA, Deny is attached at project scope, exact `compute.googleapis.com/instances.get` is denied, and test uses `--impersonate-service-account`. |
| NAT does not restore egress | Check NAT region matches VM subnet, Cloud Router/NAT status, NAT covers the subnet, default route and egress firewall; inspect NAT error logs. |
| Terraform wants to reverse manual MIG resize | Expected drift: `mig_target_size` remains 2. Either resize back to 2 or set variable to 4 and apply after the scenario. |

## 14. Evidence checklist

For each scenario submit command output, relevant Console screenshots, root cause, remediation and result.

### GCP-INC-2001
- [ ] Idle VM before/after state, stop/start command and billing explanation.
- [ ] SSH-broken VM details showing no target tag, failed SSH evidence, firewall/tag remediation, successful IAP SSH.
- [ ] MIG size 2 before, size 4 after, member status output.

### GCP-INC-2002
- [ ] `df -h` showing full/near-full data filesystem.
- [ ] Terraform plan showing disk size increase and post-resize `lsblk`/`df -h`.
- [ ] Public-read test result, bucket IAM before/after and live unauthenticated 403 after lockdown.
- [ ] NAT before/after connectivity test and NAT resource evidence.

### GCP-INC-2003
- [ ] Bucket default KMS key and new object's KMS key evidence.
- [ ] Secret version list before/after rotation; old version disabled after validation.
- [ ] Alert policy, notification channel verification, triggered incident and email notification.

### PIR-D6
- [ ] Responder Allow and Deny policy, failed impersonated API call, and successful call after remediation.
- [ ] IAP SSH failure while deny firewall is active and success after removal.
- [ ] Full disk evidence and post-expansion filesystem evidence.
- [ ] Missing alert evidence and restored alert/notification evidence.
- [ ] Formal PIR covering each fault's root cause, action taken and prevention recommendation.

## 15. Formal Post-Incident Review (PIR-D6) template

Complete one row per fault. Keep the root cause separate from the symptom.

| Fault | Impact / evidence | Root cause | Action taken | Prevention / control | Owner / follow-up |
|---|---|---|---|---|---|
| Silent alert |  |  |  |  |  |
| Identity deny |  |  |  |  |  |
| Firewall block |  |  |  |  |  |
| Full disk |  |  |  |  |  |

**PIR summary:** incident timeline, business/service impact, detection gap, recovery time, lessons learned, residual risks, and prevention actions. Map demonstrated skills to CO-01...CO-11 and EO-01...EO-05 using the official course outcome definitions (not included in the source PDF).

## 16. Official technical references

The package is pinned to HashiCorp Google provider 8.8.1 so that students use one consistent provider line. Always re-check current API availability, quotas, IAM support and pricing before deploying to a different project or region.

- Google Cloud Terraform authentication: https://docs.cloud.google.com/docs/terraform/authentication
- Google Cloud Terraform install/configure: https://docs.cloud.google.com/docs/terraform/install-configure-terraform
- Google Cloud Terraform basic commands: https://docs.cloud.google.com/docs/terraform/basic-commands
- HashiCorp Google provider 8.8.1: https://registry.terraform.io/providers/hashicorp/google/8.8.1/docs
- Create a zonal Managed Instance Group: https://docs.cloud.google.com/compute/docs/instance-groups/create-zonal-mig
- IAP TCP forwarding: https://docs.cloud.google.com/iap/docs/using-tcp-forwarding
- OS Login setup: https://docs.cloud.google.com/compute/docs/oslogin/set-up-oslogin
- Cloud NAT setup: https://docs.cloud.google.com/nat/docs/using-nat
- Cloud Storage uniform bucket-level access: https://docs.cloud.google.com/storage/docs/uniform-bucket-level-access
- Cloud Storage public access prevention: https://docs.cloud.google.com/storage/docs/public-access-prevention
- Cloud Storage CMEK: https://docs.cloud.google.com/storage/docs/encryption/customer-managed-keys
- Google Cloud default encryption at rest: https://docs.cloud.google.com/docs/security/encryption/default-encryption
- Cloud KMS key versions / lifecycle: https://docs.cloud.google.com/kms/docs/enable-disable
- Secret Manager add a secret version: https://docs.cloud.google.com/secret-manager/docs/add-secret-version
- Cloud Monitoring alert policies with Terraform: https://docs.cloud.google.com/monitoring/alerts/manage-alerts-terraform
- Cloud Monitoring notification channels with Terraform: https://docs.cloud.google.com/monitoring/alerts/notification-terraform
- IAM Deny permissions supported: https://docs.cloud.google.com/iam/docs/deny-permissions-support
- IAM roles and permissions (including Deny Admin scope): https://docs.cloud.google.com/iam/docs/roles-permissions/iam
- Compute Engine roles and permissions: https://docs.cloud.google.com/compute/docs/access/iam
- Secret Manager roles and permissions: https://docs.cloud.google.com/iam/docs/roles-permissions/secretmanager
- Terraform `google_iam_deny_policy`: https://registry.terraform.io/providers/hashicorp/google/8.8.1/docs/resources/iam_deny_policy

---

**End of runbook - Day 6 GCP Cloud Shell lab**
