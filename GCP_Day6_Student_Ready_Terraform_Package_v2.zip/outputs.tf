output "project_id" {
  value       = var.project_id
  description = "Existing project used by the lab."
}

output "region" { value = var.region }
output "zone" { value = var.zone }
output "vpc_name" { value = google_compute_network.lab.name }
output "subnet_name" { value = google_compute_subnetwork.lab.name }

output "vm_idle_name" {
  value = google_compute_instance.lab["idle"].name
}

output "vm_ssh_broken_name" {
  value = google_compute_instance.lab["ssh_broken"].name
}

output "vm_storage_name" {
  value = google_compute_instance.lab["storage"].name
}

output "vm_storage_internal_ip" {
  value = google_compute_instance.lab["storage"].network_interface[0].network_ip
}

output "data_disk_name" {
  value = google_compute_disk.data.name
}

output "mig_name" {
  value = google_compute_instance_group_manager.mig.name
}

output "bucket_name" {
  value = google_storage_bucket.lab.name
}

output "sample_object_uri" {
  value = "gs://${google_storage_bucket.lab.name}/${google_storage_bucket_object.sample.name}"
}

output "secret_id" {
  value = google_secret_manager_secret.db_password.secret_id
}

output "responder_service_account" {
  value = google_service_account.responder.email
}

output "runtime_service_account" {
  value = google_service_account.vm_runtime.email
}

output "kms_key_resource" {
  value       = var.enable_cmek ? google_kms_crypto_key.lab[0].id : null
  description = "Present only when enable_cmek=true. This resource is protected by prevent_destroy; follow the KMS cleanup note in the runbook."
}

output "cpu_alert_policy_name" {
  value = var.enable_cpu_alert ? google_monitoring_alert_policy.cpu[0].name : null
}

output "nat_router_name" {
  value       = var.enable_cloud_nat ? google_compute_router.nat[0].name : null
  description = "Cloud Router name when enable_cloud_nat=true."
}
