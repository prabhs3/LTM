# Day 5 to Day 6 - Mandatory Terraform Handoff

**Purpose:** prevent Day 6 from inheriting Day 5 state, stale working-directory metadata, or leftover Day 5 resources.

## Core rule: one Terraform root directory per lab day

Use two different Cloud Shell directories:

- Day 5: `~/gcp-day5-lab`
- Day 6: `~/gcp-day6-lab`

Each directory has its own Terraform configuration, `.terraform/` working metadata, provider lock file, and local state (`terraform.tfstate`) unless a remote backend is explicitly configured. Do not copy Day 5 `.terraform/`, `terraform.tfstate*`, `terraform.tfvars`, or saved plan files into the Day 6 directory. Do not run Day 6 commands from the Day 5 directory.

HashiCorp documents that Terraform state is associated with a working directory/backend and that the state is the mapping between configuration addresses and real cloud resources. `terraform destroy` operates against the currently selected working directory, workspace, backend and state; it is not a project-wide cleanup command.

## A. Close Day 5 in the Day 5 directory

Do this before uploading or initializing Day 6. Use the exact Day 5 folder and backend that created the Day 5 resources.

```bash
cd "$HOME/gcp-day5-lab"
pwd
gcloud auth list
gcloud config get-value project
terraform workspace list
terraform workspace show
terraform output
terraform state list
```

Record the Day 5 project ID, VPC/subnet, VM, bucket, service account, custom role, Cloud SQL instance (if enabled), Deny policy scope/name (if enabled), and optional second-project resources from Terraform outputs and the Console.

In `terraform.tfvars`, first turn off optional Day 5 items that were enabled only for the exercise, including:

```hcl
enable_cloud_sql         = false
enable_iam_deny_policy   = false
secondary_project_id    = ""
```

Only use variables that exist in the Day 5 package. If the package uses different variable names, follow its own runbook. Do not invent or add these settings to the Day 6 configuration.

Create and inspect a Day 5 destroy plan:

```bash
terraform plan -destroy -out=day5-destroy.tfplan
terraform show day5-destroy.tfplan
```

**Stop and investigate** if the plan targets the wrong project, any non-Day 5 resource, a shared network, an unrelated service account, or an organization-level policy not clearly owned by this Day 5 lab. If the plan is correct, execute the saved plan:

```bash
terraform apply day5-destroy.tfplan
terraform state list
```

If the Day 5 folder has more than one workspace, repeat the plan/review/destroy workflow for each workspace that owns Day 5 resources. Do not assume the default workspace is the only state. Expected result: Day 5 managed resources are removed from the Day 5 state. Keep the Day 5 directory and state file until the cleanup inventory below is complete. Do not delete the folder as a way to clean up cloud resources.

## B. Check for Day 5 leftovers in the GCP Console and CLI

The Day 5 student guide says resource IDs and the bucket name are generated; use the actual outputs captured before destroy rather than guessing a prefix. Compare the Day 5 inventory with these project-level listings. Keep `gcloud` set to the Day 5 project while running this inventory. If Day 6 will use a different project, switch to the Day 6 project only after the Day 5 checks are complete:

```bash
PROJECT_ID="$(gcloud config get-value project 2>/dev/null)"
gcloud compute instances list --project="$PROJECT_ID"
gcloud compute disks list --project="$PROJECT_ID"
gcloud compute networks list --project="$PROJECT_ID"
gcloud compute firewall-rules list --project="$PROJECT_ID"
gcloud storage buckets list --project="$PROJECT_ID"
gcloud sql instances list --project="$PROJECT_ID"
gcloud iam service-accounts list --project="$PROJECT_ID"
```

In Console, inspect:

1. **Compute Engine → VM instances / Disks:** Day 5 VM and disk names should be absent.
2. **VPC network → VPC networks / Firewall:** the Day 5 network, subnet and lab firewall rules should be absent.
3. **Cloud Storage → Buckets:** the Day 5 bucket should be absent.
4. **IAM & Admin → Service Accounts / Roles:** the Day 5 test service account and custom role should be absent unless deliberately retained by the instructor.
5. **SQL → Instances:** the optional Day 5 Cloud SQL instance should be absent.
6. **IAM & Admin → Deny policies:** verify only the exact Day 5 lab Deny policy has been removed. Do not delete a shared or unrelated organization policy.

If a Day 5 resource remains, determine whether it was manually created outside Terraform, omitted from the Day 5 state, retained by design, or protected by a policy. Remove it only through the owning configuration or instructor-approved procedure. Do not use broad project cleanup commands.

### APIs are different from lab resources

Some Google APIs may remain enabled after Day 5 destroy. This is not, by itself, a stale infrastructure resource. Day 6 also requires several of the same APIs. Do not disable APIs manually as part of this transition. The Day 6 configuration manages its required API enablement and leaves APIs enabled on destroy.

## C. Prepare a clean Day 6 working directory

Only after Day 5 destroy and inventory verification:

```bash
cd "$HOME"
mkdir -p "$HOME/gcp-day6-lab"
cd "$HOME/gcp-day6-lab"
pwd
ls -la
```

If this directory already contains `.terraform/`, `terraform.tfstate`, `terraform.tfstate.backup`, `terraform.tfstate.d/`, a backend configuration, or a prior `terraform.tfvars`, **do not overwrite or delete it**. It may be a previous Day 6 deployment. Return to that exact folder and inspect its workspace/state; resume it or clean it up using its own reviewed Day 6 destroy plan.

Upload the Day 6 ZIP and extract it into the Day 6 folder only. Confirm the Terraform root files are at the current directory level:

```bash
unzip -o "$HOME/GCP_Day6_Student_Ready_Terraform_Package.zip" -d "$HOME/gcp-day6-lab"
cd "$HOME/gcp-day6-lab"
printf 'Working directory: '; pwd
ls -1 *.tf terraform.tfvars.example
```

Do not copy the Day 5 `.terraform/` directory, state, plan files, `terraform.tfvars`, or provider lock file into Day 6. Let Day 6 initialize the provider version constrained by its own `versions.tf` (`hashicorp/google ~> 8.8.1`) and retain the generated `.terraform.lock.hcl` thereafter.

## D. Confirm Day 6 naming and state isolation

The supplied Day 6 configuration defaults to `name_prefix = "d6"`. Most Day 6 names begin with `d6-<first-eight-characters-of-project-id>`, for example `d6-example-vpc`; the bucket name uses the Day 6 prefix and full project ID. The resource labels include `course_day=day6` where supported. These names are intentionally distinct from the Day 5 guide's generated resource IDs, but names alone are not a substitute for checking the state and Console inventory.

For multiple students sharing one project, assign a unique short prefix in `terraform.tfvars`, for example `d6-s01`, `d6-s02`, etc. The prefix must satisfy the validation in `variables.tf` (lowercase letters, digits and hyphens; maximum 10 characters). Do not give two students the same prefix in one project.

Before `terraform init`, verify:

```bash
pwd
cat terraform.tfvars.example
```

After `terraform init`, verify the workspace and state context:

```bash
terraform workspace show
terraform state list
```

A first-time Day 6 deployment should not have pre-existing managed Day 6 resources in its state. If a `d6-...` resource already exists in GCP but is not tracked in this Day 6 state, stop. It may be a previous Day 6 attempt or a leftover from an earlier state problem. Do not apply blindly; recover the correct Day 6 state or import only the exact resource after instructor review.

## E. Final handoff checklist

- [ ] Day 5 destroy was run from the original Day 5 directory/backend/workspace.
- [ ] The Day 5 destroy plan was reviewed before apply.
- [ ] Day 5 managed state has no remaining managed resource addresses.
- [ ] Day 5 VM, disk, VPC/subnet/firewalls, bucket, SQL (if enabled), test service account/custom role and Deny policy were checked in Console/CLI.
- [ ] Any intentional leftovers or organization-level resources are documented and approved by the instructor.
- [ ] Shared APIs were not manually disabled.
- [ ] Day 6 uses `~/gcp-day6-lab`, a separate state and the Day 6 provider lock file.
- [ ] Day 6 resource prefix is unique within the target project.
- [ ] Day 6 plan is reviewed and contains only Day 6 resources.

**Never run `rm -rf` against either lab directory as a substitute for Terraform destroy. Never delete or copy a state file to make a 409 error disappear.**
