# GCP Day 5 Terraform Lab - Cloud Shell Edition

A disposable, Terraform-managed lab for the four Day 5 scenarios in the supplied training deck. Run Terraform from **Google Cloud Shell (Bash)**. The configuration targets an **existing project**; it does not create a new GCP project or change the project billing account.

## What the pack provisions

- Custom VPC and subnet, with an IAP-only SSH firewall path.
- One small Compute Engine VM in `us-central1-b`, without an external IP, for the IaaS/guest-OS and zone-discovery exercises.
- A dedicated `svc-nightops`-style service account; initially over-permissioned with project-level Editor solely to create the before-state for the least-privilege exercise.
- A project custom role containing only `compute.instances.get`, `compute.instances.start`, and `compute.instances.stop`, and a switch to bind it to the lab VM only.
- A random-suffix Cloud Storage bucket and synthetic `internal-reports/report.txt`, with `roles/storage.objectViewer` granted to the lab service account.
- Optional Cloud SQL for PostgreSQL. **Disabled by default** because it is billable.
- Optional real IAM Deny policy. **Disabled by default**; can attach at project scope or organization scope if the required administrative permissions are available.
- Optional second-project VM to make GCP-INC-1002 a true cross-project discovery exercise. **Disabled by default**; requires a second existing project with billing and sufficient permissions.

## Prerequisites

1. An existing Google Cloud project with billing enabled. Prefer a disposable training project.
2. Permissions to enable APIs and create Compute Engine, VPC, IAM, Cloud Storage, and optionally Cloud SQL resources. For the before/after IAM exercise, you need permissions to change IAM bindings and create custom roles.
3. For a real organization-level Deny policy, you need an organization ID and appropriate IAM Deny policy administration permissions at that organization. Do not attempt this in a production organization.
4. Cloud Shell enabled in the Google Cloud Console.

## 1. Open Cloud Shell and check your project

Click **Activate Cloud Shell** in the Google Cloud Console. Cloud Shell is Bash-based. Replace the project ID below with the dedicated project you intend to use:

```bash
gcloud config get-value project
gcloud projects describe "$(gcloud config get-value project)" --format='table(projectId,lifecycleState)'
gcloud billing projects describe "$(gcloud config get-value project)" --format='yaml(projectId,billingAccountName,billingEnabled)'
gcloud auth list
```

If the active project is not the lab project:

```bash
gcloud config set project YOUR_EXISTING_PROJECT_ID
```

Before the first Terraform run, ensure the Service Usage API is enabled. If using the optional second project, do this in that project too:

```bash
PROJECT_ID="$(gcloud config get-value project 2>/dev/null)"
gcloud services enable serviceusage.googleapis.com cloudresourcemanager.googleapis.com --project="$PROJECT_ID"
```

## 2. Upload and extract this package

Download `GCP_Day5_Terraform_Lab_Package.zip` from the chat to your computer. In Cloud Shell, select **Manage files → Upload** and upload the ZIP into your home directory. Then run:

```bash
mkdir -p "$HOME/gcp-day5-lab"
unzip -o "$HOME/GCP_Day5_Terraform_Lab_Package.zip" -d "$HOME/gcp-day5-lab"
cd "$HOME/gcp-day5-lab/GCP_Day5_Terraform_Lab_Package"
ls -la
```

If the extracted directory name is different, use `find "$HOME/gcp-day5-lab" -maxdepth 2 -name main.tf` to locate it, then `cd` into the directory containing `main.tf`.

## 3. Create your configuration file

```bash
cp terraform.tfvars.example terraform.tfvars
nano terraform.tfvars
```

Set at least these values:

- `project_id`: your existing project ID (not the display name).
- `lab_user_email`: the Google account email you use in Cloud Shell. Leave blank if you do not want the optional IAP / service-account impersonation grants.
- `secondary_project_id`: leave blank unless you have a second existing, billed project and want a real cross-project discovery scenario.
- Keep `enable_cloud_sql = false`, `enable_custom_role_binding = false`, and `enable_iam_deny_policy = false` for the initial build.

Save in nano with `Ctrl+O`, Enter, then exit with `Ctrl+X`.

## 4. Initialize, validate, plan, inspect, deploy

Cloud Shell may already have Terraform installed. Check first:

```bash
terraform version
gcloud config get-value project
```

If Terraform is not available, follow Google's current instructions: https://docs.cloud.google.com/docs/terraform/install-configure-terraform

Then run, one command at a time:

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform show tfplan
```

Review the plan. It should use only the project ID in `terraform.tfvars`. Confirm any optional billable resources are still disabled. If the plan looks expected, deploy:

```bash
terraform apply tfplan
terraform output
```

The initial deployment creates a VM and persistent disk. They can incur charges while they exist; the absence of an external IP is a security control, not a billing waiver.

## Scenario proof guides

Use the detailed `DAY5_SCENARIO_RUNBOOK.md` for the exact commands, expected output and evidence checklist. High-level sequence:

1. **GCP-INC-1001, Cloud SQL PaaS:** set `enable_cloud_sql = true`, apply, describe the Cloud SQL instance, compare it with the Compute Engine VM, then set it back to false and apply to remove the billable database.
2. **GCP-INC-1002, Project/zone discovery:** search the wrong zone, then search the VM's actual zone. If `secondary_project_id` is set, also demonstrate that the secondary VM appears only when you query that project.
3. **GCP-INC-1003, Least privilege:** capture the service account's Editor binding. Change `seed_editor_binding = false` and `enable_custom_role_binding = true`; apply; verify the project-level Editor binding is gone and the custom role is attached to the single lab VM. Do not re-apply with the original settings after remediation, or Terraform will restore the Editor before-state.
4. **GCP-INC-1004, Deny precedence:** first prove the service account can read the synthetic object through its Storage Object Viewer binding. Then enable the Deny policy and repeat the access test. For exact org-level parity set `deny_policy_scope = "organization"` and set `organization_id`; in a standalone project use `project` scope only as a fallback demonstration, clearly labelled as such.

## Cost and safety controls

- Cloud SQL is disabled by default. Enable only during its exercise and switch it off afterward.
- A second-project VM is disabled by default. It creates billable resources in a second project if enabled.
- Do not place real secrets or customer data in the bucket. The object is synthetic.
- The Editor binding is deliberately granted to a **dedicated lab service account only** to show the before-state. Never use an existing workload service account.
- The optional Deny policy denies only `storage.googleapis.com/objects.get` for that lab service account. At organization scope the rule is inherited through the organization hierarchy, so use only the dedicated lab identity.
- Do not generate or download service-account keys. The optional test path uses service-account impersonation.
- Terraform state can contain generated SQL credentials and IAM configuration. Keep it private; do not upload it to a public repository or share it with students.

## Cleanup

From the same directory, inspect resources first:

```bash
terraform state list
terraform plan -destroy
```

If the plan contains only the lab resources you intend to remove, run:

```bash
terraform destroy
```

Type `yes` when prompted. If any optional policy was attached to an organization, verify that the policy is removed before leaving. Review the project in the Cloud Console for anything created manually outside Terraform, because `terraform destroy` only removes resources tracked by this Terraform state.

## Authoritative references

- Terraform on Google Cloud / installation: https://docs.cloud.google.com/docs/terraform/install-configure-terraform
- Terraform authentication: https://docs.cloud.google.com/docs/terraform/authentication
- Cloud SQL for PostgreSQL: https://docs.cloud.google.com/sql/docs/postgres/create-instance
- Compute Engine VM listing: https://docs.cloud.google.com/compute/docs/instances/get-list
- Custom IAM roles: https://docs.cloud.google.com/iam/docs/creating-custom-roles
- IAM Deny policies: https://docs.cloud.google.com/iam/docs/deny-access
- IAM Deny policy supported permissions: https://docs.cloud.google.com/iam/docs/deny-permissions-support
- Terraform `google_iam_deny_policy`: https://registry.terraform.io/providers/hashicorp/google/latest/docs/resources/iam_deny_policy
