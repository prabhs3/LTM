terraform {
  required_version = ">= 1.5.0"

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 7.0"
    }
    google-beta = {
      source  = "hashicorp/google-beta"
      version = "~> 7.0"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
  zone    = var.vm_zone
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
  zone    = var.vm_zone
}

# Optional second-project provider. When secondary_project_id is blank it points
# at the main project, but the optional resources below have count=0.
provider "google" {
  alias   = "secondary"
  project = trimspace(var.secondary_project_id) == "" ? var.project_id : var.secondary_project_id
  region  = var.region
  zone    = var.secondary_vm_zone
}

locals {
  required_services = toset([
    "compute.googleapis.com",
    "sqladmin.googleapis.com",
    "iam.googleapis.com",
    "iamcredentials.googleapis.com",
    "cloudresourcemanager.googleapis.com",
    "storage.googleapis.com",
    "iap.googleapis.com",
  ])
}

# Enables the APIs needed by the lab. The Service Usage API should be enabled
# once in Cloud Shell before the first Terraform run (see README).
resource "google_project_service" "required" {
  for_each = local.required_services

  project            = var.project_id
  service            = each.value
  disable_on_destroy = false
}

resource "random_id" "bucket_suffix" {
  byte_length = 3
}

# -------------------------- Network and VM --------------------------
resource "google_compute_network" "lab" {
  name                    = "${var.name_prefix}-vpc"
  auto_create_subnetworks = false
  routing_mode            = "REGIONAL"
  description             = "Isolated network for the Day 5 cloud foundations lab"

  depends_on = [google_project_service.required]
}

resource "google_compute_subnetwork" "lab" {
  name                     = "${var.name_prefix}-subnet"
  region                   = var.region
  network                  = google_compute_network.lab.id
  ip_cidr_range             = "10.55.1.0/24"
  private_ip_google_access = true
  description              = "Subnet for the Day 5 resource-discovery VM"
}

# IAP-only SSH. The VM has no external IP; SSH is not exposed to the internet.
resource "google_compute_firewall" "iap_ssh" {
  name      = "${var.name_prefix}-allow-iap-ssh"
  network   = google_compute_network.lab.name
  direction = "INGRESS"
  priority  = 1000

  source_ranges = ["35.235.240.0/20"]
  target_tags   = ["${var.name_prefix}-vm"]

  allow {
    protocol = "tcp"
    ports    = ["22"]
  }

  description = "Allow SSH only through Identity-Aware Proxy TCP forwarding"
}

# Optional true cross-project discovery exercise. Requires an existing, billed
# second project with permissions to enable Compute Engine and create resources.
resource "google_project_service" "secondary_compute" {
  count    = trimspace(var.secondary_project_id) == "" ? 0 : 1
  provider = google.secondary
  project  = var.secondary_project_id
  service  = "compute.googleapis.com"
  disable_on_destroy = false
}

resource "google_compute_network" "secondary_lab" {
  count                   = trimspace(var.secondary_project_id) == "" ? 0 : 1
  provider                = google.secondary
  project                 = var.secondary_project_id
  name                    = "${var.name_prefix}-secondary-vpc"
  auto_create_subnetworks = false
  routing_mode            = "REGIONAL"
  depends_on              = [google_project_service.secondary_compute]
}

resource "google_compute_subnetwork" "secondary_lab" {
  count        = trimspace(var.secondary_project_id) == "" ? 0 : 1
  provider     = google.secondary
  project      = var.secondary_project_id
  name         = "${var.name_prefix}-secondary-subnet"
  region       = var.region
  network      = google_compute_network.secondary_lab[0].id
  ip_cidr_range = "10.56.1.0/24"
}

resource "google_compute_instance" "secondary_discovery" {
  count        = trimspace(var.secondary_project_id) == "" ? 0 : 1
  provider     = google.secondary
  project      = var.secondary_project_id
  name         = "${var.name_prefix}-vm-secondary-01"
  zone         = var.secondary_vm_zone
  machine_type = var.vm_machine_type
  tags         = ["${var.name_prefix}-secondary-vm"]
  deletion_protection = false

  boot_disk {
    initialize_params {
      image = "debian-cloud/debian-12"
      size  = 10
      type  = "pd-balanced"
    }
  }

  network_interface {
    network    = google_compute_network.secondary_lab[0].id
    subnetwork = google_compute_subnetwork.secondary_lab[0].id
  }

  labels = {
    environment = "training"
    day          = "day5"
    managed_by   = "terraform"
  }
}

resource "google_compute_instance" "resource_hunt" {
  name                      = "${var.name_prefix}-vm-app-02"
  project                   = var.project_id
  zone                      = var.vm_zone
  machine_type              = var.vm_machine_type
  allow_stopping_for_update = true
  deletion_protection       = false
  tags                      = ["${var.name_prefix}-vm"]
  description               = "Day 5 resource-discovery and IaaS guest-OS demonstration VM"

  boot_disk {
    initialize_params {
      image = "debian-cloud/debian-12"
      size  = 10
      type  = "pd-balanced"
    }
  }

  network_interface {
    network    = google_compute_network.lab.id
    subnetwork = google_compute_subnetwork.lab.id
    # Deliberately no access_config: no external IPv4 address.
  }

  metadata = {
    "enable-oslogin" = "TRUE"
  }

  labels = {
    environment = "training"
    day          = "day5"
    managed_by   = "terraform"
  }

  depends_on = [google_project_service.required]
}

# Optional instance-login grants are limited to the named current lab user.
# Supply lab_user_email to enable the IAP + OS Login path for Compute Engine.
resource "google_project_iam_member" "lab_user_iap_tunnel" {
  count   = trimspace(var.lab_user_email) == "" ? 0 : 1
  project = var.project_id
  role    = "roles/iap.tunnelResourceAccessor"
  member  = "user:${var.lab_user_email}"
}

resource "google_project_iam_member" "lab_user_oslogin" {
  count   = trimspace(var.lab_user_email) == "" ? 0 : 1
  project = var.project_id
  role    = "roles/compute.osLogin"
  member  = "user:${var.lab_user_email}"
}

# --------------------------- Cloud SQL ------------------------------
# Cloud SQL is disabled by default because it is billable. Enable only while
# running GCP-INC-1001, then turn it off and apply to delete it.
resource "random_password" "sql_lab_user" {
  count            = var.enable_cloud_sql ? 1 : 0
  length           = 24
  special          = false
  override_special = ""
}

resource "google_sql_database_instance" "lab" {
  count            = var.enable_cloud_sql ? 1 : 0
  name             = "${var.name_prefix}-sql-pg"
  project          = var.project_id
  region           = var.region
  database_version = var.sql_database_version
  deletion_protection = false

  settings {
    tier              = var.sql_tier
    edition            = "ENTERPRISE"
    availability_type  = "ZONAL"
    disk_size          = 10
    disk_type          = "PD_SSD"
    disk_autoresize    = false

    backup_configuration {
      enabled = false
    }

    ip_configuration {
      ipv4_enabled = true
      require_ssl  = true
      # No authorized networks are configured. Do not add 0.0.0.0/0.
    }
  }

  depends_on = [google_project_service.required]
}

resource "google_sql_database" "lab" {
  count    = var.enable_cloud_sql ? 1 : 0
  project  = var.project_id
  name     = "bootcamp"
  instance = google_sql_database_instance.lab[0].name
}

resource "google_sql_user" "lab" {
  count    = var.enable_cloud_sql ? 1 : 0
  project  = var.project_id
  name     = "labuser"
  instance = google_sql_database_instance.lab[0].name
  password = random_password.sql_lab_user[0].result
}

# -------------------- Least privilege: service account --------------------
resource "google_service_account" "nightops" {
  project      = var.project_id
  account_id   = "${var.name_prefix}-svc-nightops"
  display_name = "Day 5 lab service account - Night Ops"
  description  = "Disposable lab identity for least-privilege and Deny-precedence demonstrations"

  depends_on = [google_project_service.required]
}

# Deliberately seeds an over-permissioned BEFORE state for the exercise.
# This grants Editor only to the lab service account, not to a human user.
resource "google_project_iam_member" "editor_seed" {
  count   = var.seed_editor_binding ? 1 : 0
  project = var.project_id
  role    = "roles/editor"
  member  = "serviceAccount:${google_service_account.nightops.email}"
}

resource "google_project_iam_custom_role" "nightops" {
  project     = var.project_id
  role_id     = "${var.name_prefix}NightOpsReadRestart"
  title       = "Night Ops Read and Restart"
  description = "Lab custom role: inspect, start, and stop only the VM to which it is bound"
  stage       = "GA"

  permissions = [
    "compute.instances.get",
    "compute.instances.start",
    "compute.instances.stop",
  ]
}

# The custom role is bound at the VM resource, rather than project scope.
# During remediation set seed_editor_binding=false and
# enable_custom_role_binding=true, then terraform apply.
resource "google_compute_instance_iam_member" "nightops_scoped" {
  count         = var.enable_custom_role_binding ? 1 : 0
  project       = var.project_id
  zone          = google_compute_instance.resource_hunt.zone
  instance_name = google_compute_instance.resource_hunt.name
  role          = google_project_iam_custom_role.nightops.name
  member        = "serviceAccount:${google_service_account.nightops.email}"
}

# Permit only the current user to impersonate this one test service account.
# No service-account key is generated or downloaded.
resource "google_service_account_iam_member" "lab_user_impersonation" {
  count              = trimspace(var.lab_user_email) == "" ? 0 : 1
  service_account_id = google_service_account.nightops.name
  role               = "roles/iam.serviceAccountTokenCreator"
  member             = "user:${var.lab_user_email}"
}

# -------------------- Storage and Deny precedence --------------------
resource "google_storage_bucket" "lab" {
  name                        = "${var.bucket_name_prefix}-${random_id.bucket_suffix.hex}"
  project                     = var.project_id
  location                    = var.region
  uniform_bucket_level_access = true
  public_access_prevention    = "enforced"
  force_destroy               = true

  labels = {
    environment = "training"
    day          = "day5"
    managed_by   = "terraform"
  }

  depends_on = [google_project_service.required]
}

resource "google_storage_bucket_object" "sample" {
  name    = "internal-reports/report.txt"
  bucket  = google_storage_bucket.lab.name
  content = "Synthetic Day 5 training report. No confidential data.\n"
}

resource "google_storage_bucket_iam_member" "object_viewer" {
  bucket = google_storage_bucket.lab.name
  role   = "roles/storage.objectViewer"
  member = "serviceAccount:${google_service_account.nightops.email}"
}


resource "terraform_data" "deny_scope_guard" {
  input = var.deny_policy_scope

  lifecycle {
    precondition {
      condition = !var.enable_iam_deny_policy || var.deny_policy_scope != "organization" || trimspace(var.organization_id) != ""
      error_message = "When enable_iam_deny_policy=true and deny_policy_scope=organization, set organization_id to the numeric ID of the approved training organization."
    }
  }
}

# This resource is disabled unless explicitly requested. Project scope is the
# safe fallback in a standalone project. For exact GCP-INC-1004 parity, set
# deny_policy_scope="organization" and provide organization_id, using a
# dedicated lab service account only.
resource "google_iam_deny_policy" "storage_get_deny" {
  provider = google-beta
  count    = var.enable_iam_deny_policy ? 1 : 0

  parent = urlencode(
    var.deny_policy_scope == "organization"
    ? "cloudresourcemanager.googleapis.com/organizations/${var.organization_id}"
    : "cloudresourcemanager.googleapis.com/projects/${var.project_id}"
  )
  name         = "${var.name_prefix}-storage-get-deny"
  display_name = "Day 5 lab - deny object reads for the lab service account"

  rules {
    description = "Demonstrate explicit Deny overriding Storage Object Viewer Allow"

    deny_rule {
      denied_principals = [
        "principal://iam.googleapis.com/projects/-/serviceAccounts/${google_service_account.nightops.email}"
      ]
      denied_permissions = ["storage.googleapis.com/objects.get"]
    }
  }

  depends_on = [google_storage_bucket_iam_member.object_viewer, terraform_data.deny_scope_guard]
}
