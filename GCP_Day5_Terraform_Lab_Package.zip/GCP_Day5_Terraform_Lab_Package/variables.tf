variable "project_id" {
  description = "Existing GCP project ID with billing enabled. The configuration does not create a project."
  type        = string
}

variable "region" {
  description = "Region for the lab network and optional Cloud SQL instance."
  type        = string
  default     = "us-central1"
}

variable "vm_zone" {
  description = "Zone for the resource-hunt VM. Keep this different from the zone filter used in the discovery exercise."
  type        = string
  default     = "us-central1-b"
}

variable "name_prefix" {
  description = "Lowercase resource-name prefix, 4-10 characters recommended."
  type        = string
  default     = "gcpd5lab"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,9}$", var.name_prefix))
    error_message = "name_prefix must start with a lowercase letter and contain 3-10 lowercase letters, digits or hyphens."
  }
}

variable "bucket_name_prefix" {
  description = "Lowercase global bucket-name prefix; Terraform appends a random suffix."
  type        = string
  default     = "day5-lab-report"
}

variable "secondary_project_id" {
  description = "Optional existing billed project used to demonstrate true cross-project resource discovery. Leave blank to avoid creating a second VM."
  type        = string
  default     = ""
}

variable "secondary_vm_zone" {
  description = "Zone for the optional cross-project discovery VM."
  type        = string
  default     = "us-central1-c"
}

variable "vm_machine_type" {
  description = "Small Compute Engine machine type for the discovery lab."
  type        = string
  default     = "e2-micro"
}

variable "lab_user_email" {
  description = "Optional student/instructor Google identity (email). When set, grants IAP SSH, OS Login and impersonation on the lab-only service account."
  type        = string
  default     = ""
}

variable "enable_cloud_sql" {
  description = "Create billable Cloud SQL PostgreSQL resources for GCP-INC-1001. Enable only for that scenario."
  type        = bool
  default     = false
}

variable "sql_database_version" {
  description = "Cloud SQL database version used when enable_cloud_sql=true."
  type        = string
  default     = "POSTGRES_15"
}

variable "sql_tier" {
  description = "Cloud SQL machine tier. Availability varies by project, region and current service offerings."
  type        = string
  default     = "db-f1-micro"
}

variable "seed_editor_binding" {
  description = "Seed project-level Editor on the lab-only service account to create the before state in GCP-INC-1003. Do not use a real workload identity."
  type        = bool
  default     = true
}

variable "enable_custom_role_binding" {
  description = "Bind the lab custom role to the target VM. For remediation, set this true while setting seed_editor_binding=false."
  type        = bool
  default     = false
}

variable "enable_iam_deny_policy" {
  description = "Create a real IAM Deny policy for GCP-INC-1004. Requires additional permissions; default false."
  type        = bool
  default     = false
}

variable "deny_policy_scope" {
  description = "Use project for a standalone-project demonstration, or organization for exact org-level scenario parity."
  type        = string
  default     = "project"

  validation {
    condition     = contains(["project", "organization"], var.deny_policy_scope)
    error_message = "deny_policy_scope must be either project or organization."
  }
}

variable "organization_id" {
  description = "Numeric organization ID. Required only when enable_iam_deny_policy=true and deny_policy_scope=organization."
  type        = string
  default     = ""
}
