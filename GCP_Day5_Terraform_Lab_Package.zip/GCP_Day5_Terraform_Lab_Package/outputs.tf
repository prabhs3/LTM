output "project_id" {
  description = "Project used for the lab."
  value       = var.project_id
}

output "region" {
  value = var.region
}

output "vm_name" {
  description = "VM for the Compute Engine/IaaS and resource-discovery scenarios."
  value       = google_compute_instance.resource_hunt.name
}

output "vm_zone" {
  value = google_compute_instance.resource_hunt.zone
}

output "network_name" {
  value = google_compute_network.lab.name
}

output "subnet_name" {
  value = google_compute_subnetwork.lab.name
}

output "subnet_cidr" {
  value = google_compute_subnetwork.lab.ip_cidr_range
}

output "service_account_email" {
  description = "Dedicated service account used for the least-privilege and Deny labs."
  value       = google_service_account.nightops.email
}

output "custom_role_name" {
  value = google_project_iam_custom_role.nightops.name
}

output "bucket_name" {
  value = google_storage_bucket.lab.name
}

output "bucket_object_uri" {
  value = "gs://${google_storage_bucket.lab.name}/${google_storage_bucket_object.sample.name}"
}

output "cloud_sql_instance_name" {
  value = var.enable_cloud_sql ? google_sql_database_instance.lab[0].name : "disabled - set enable_cloud_sql=true to create"
}

output "cloud_sql_lab_user" {
  value = var.enable_cloud_sql ? google_sql_user.lab[0].name : "disabled"
}

output "cloud_sql_lab_password" {
  description = "Random password for the lab-only SQL user. Available only when Cloud SQL is enabled. Keep it private."
  value       = var.enable_cloud_sql ? random_password.sql_lab_user[0].result : null
  sensitive   = true
}

output "iam_deny_policy" {
  value = var.enable_iam_deny_policy ? google_iam_deny_policy.storage_get_deny[0].name : "disabled - use project-scope fallback or enable explicitly"
}

output "secondary_project_vm_name" {
  description = "Optional VM used to demonstrate cross-project discovery. Disabled when secondary_project_id is empty."
  value       = trimspace(var.secondary_project_id) == "" ? "disabled - set secondary_project_id to an existing billed project" : google_compute_instance.secondary_discovery[0].name
}

output "secondary_project_vm_project" {
  value = trimspace(var.secondary_project_id) == "" ? "disabled" : var.secondary_project_id
}
