# Quick Start - GCP Day 5 Terraform Lab

1. Open Google Cloud Shell (Bash), and confirm your selected project and billing.
2. Upload and extract the ZIP. `cd` into the folder containing `main.tf`.
3. Run `cp terraform.tfvars.example terraform.tfvars`; edit the file with your existing project ID and Google account email.
4. Run `terraform init`, `terraform fmt -recursive`, `terraform validate`, `terraform plan -out=tfplan`, inspect `terraform show tfplan`, then `terraform apply tfplan`.
5. Follow `DAY5_SCENARIO_RUNBOOK.md` for scenario evidence. Cloud SQL, the second-project VM, the custom role binding, and IAM Deny are gated by variables.
6. Clean up with `terraform plan -destroy`, then `terraform destroy` and confirm the plan targets only lab resources.

**Safety:** do not use a production project. Cloud SQL and Compute Engine can generate charges. The project Editor grant is deliberately applied only to the dedicated lab service account for the least-privilege before-state. IAM Deny at organization scope requires specific permissions and must not be enabled in a production organization.
