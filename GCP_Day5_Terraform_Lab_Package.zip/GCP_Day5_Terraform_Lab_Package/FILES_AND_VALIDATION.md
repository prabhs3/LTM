# Package Contents and Validation Status

## Files

- `main.tf` - baseline VPC/subnet, private Compute Engine VM, IAP-only SSH firewall, optional second-project discovery VM, optional Cloud SQL, service account, custom role, Storage bucket/object, and optional IAM Deny policy.
- `variables.tf` - project, zone, service-account, Cloud SQL, IAM role, second-project and Deny-policy settings.
- `outputs.tf` - resource identifiers for scenario commands.
- `terraform.tfvars.example` - starter values; copy to `terraform.tfvars` and update before use.
- `README.md` - Cloud Shell deployment and cleanup.
- `DAY5_SCENARIO_RUNBOOK.md` - commands, expected outcomes, and evidence for all four scenarios.
- `README_STUDENT_SHORT.md` - quick start.
- `docs/` - formatted Word and PDF guides.

## Validation status

The documents and configuration were reviewed for structure, variable references and dependency intent, and the Word/PDF guide was rendered and visually checked. This authoring environment does not have Terraform installed and cannot authenticate to the learner's Google Cloud project, so `terraform init`, `terraform validate`, `terraform plan`, and a live deployment have **not** been executed here.

Run these checks in Google Cloud Shell before applying:

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan -out=tfplan
terraform show tfplan
```

Do not apply if the plan targets an unexpected project or includes optional resources that you did not enable.
