# Day 5 Scenario Map

| Scenario | Provisioned support | Proof path | Important limitation |
|---|---|---|---|
| GCP-INC-1001 | Optional Cloud SQL PostgreSQL + Compute Engine VM | `gcloud sql instances describe` and `gcloud compute ssh --tunnel-through-iap` | Cloud SQL is disabled by default and billable; enable only for this exercise. |
| GCP-INC-1002 | VM in `us-central1-b`; optional secondary-project VM | Query wrong zone/project, then the correct zone/project | Without `secondary_project_id`, the live proof is a zone-filter example; the pack does not fabricate a second project. |
| GCP-INC-1003 | Dedicated service account starts with Editor; custom role can be bound directly to one VM | Capture before-state, toggle `seed_editor_binding=false`, `enable_custom_role_binding=true`, then inspect after-state | Requires project IAM administration rights; the Editor before-state is only for the dedicated lab SA. |
| GCP-INC-1004 | Bucket-level Storage Object Viewer Allow and optional IAM Deny | Read object through impersonated SA, enable Deny, read again | Exact organization-level proof requires organization ID and IAM Deny admin rights; project scope is a fallback, not identical. |
