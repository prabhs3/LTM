# Day 5 GCP Lab - Scenario Proof Runbook

This runbook supports the four scenarios defined in the Day 5 source deck. The command outputs below are **illustrative patterns**; project IDs, generated bucket names, instance names, timestamps, and API formatting can differ. Capture the actual output from your sandbox.

## Initial variables

Run from the folder containing the Terraform files:

```bash
PROJECT_ID="$(terraform output -raw project_id)"
VM_NAME="$(terraform output -raw vm_name)"
VM_ZONE="$(terraform output -raw vm_zone)"
SA_EMAIL="$(terraform output -raw service_account_email)"
BUCKET="$(terraform output -raw bucket_name)"
OBJ="gs://${BUCKET}/internal-reports/report.txt"
echo "Project: $PROJECT_ID"
echo "VM: $VM_NAME ($VM_ZONE)"
echo "Lab service account: $SA_EMAIL"
echo "Synthetic object: $OBJ"
```

Baseline inventory:

```bash
gcloud compute instances list --project="$PROJECT_ID" --format='table(name,status,zone,networkInterfaces[0].networkIP)'
gcloud storage buckets describe "gs://${BUCKET}"
gcloud iam service-accounts describe "$SA_EMAIL" --project="$PROJECT_ID"
```

Expected: one lab VM in the configured zone, one private (no-external-IP) VM, one private synthetic bucket, and a dedicated service account.

---

## GCP-INC-1001 - IaaS vs PaaS: Compute Engine vs Cloud SQL

### Objective
Use the guest-OS access boundary and resource metadata to distinguish Compute Engine (IaaS) from Cloud SQL (managed database / PaaS).

### Provision Cloud SQL only for this scenario

Edit `terraform.tfvars` and set:

```hcl
enable_cloud_sql = true
```

Then run:

```bash
terraform plan -out=tfplan
terraform apply tfplan
```

If the line above gets copied incorrectly, the intended command is `terraform apply tfplan` (with no space after the first `t`).

After deployment:

```bash
SQL_NAME="$(terraform output -raw cloud_sql_instance_name)"
gcloud sql instances describe "$SQL_NAME" --project="$PROJECT_ID" --format='yaml(name,region,databaseVersion,instanceType,ipAddresses,settings.tier)'
gcloud sql instances describe "$SQL_NAME" --project="$PROJECT_ID" --format='value(instanceType)'
```

Illustrative expected value for `instanceType`:

```text
CLOUD_SQL_INSTANCE
```

Now demonstrate guest-OS access on Compute Engine (when `lab_user_email` is set and IAP/OS Login permissions are granted):

```bash
gcloud compute ssh "$VM_NAME" --project="$PROJECT_ID" --zone="$VM_ZONE" --tunnel-through-iap
```

Inside the VM:

```bash
hostname
cat /etc/os-release
exit
```

Teaching point: the VM provides a guest operating system that the customer administers. Cloud SQL exposes a managed database interface; the customer does not log in to its underlying host OS to patch the OS or database engine. A database endpoint being present does not make it IaaS.

### Cost cleanup after evidence

Set `enable_cloud_sql = false` in `terraform.tfvars`, then run:

```bash
terraform plan -out=tfplan
terraform apply tfplan
```

Expected: Terraform proposes removing the Cloud SQL instance, database, SQL user and generated password resource. Confirm the plan only targets the lab database resources.

---

## GCP-INC-1002 - Wrong project / zone resource discovery

### Objective
Show that the active project and a restrictive zone filter can make a VM appear to be missing. Search before provisioning a duplicate.

Check the active project and configured zone:

```bash
gcloud config get-value project
gcloud config get-value compute/zone
gcloud projects list --filter='lifecycleState=ACTIVE' --format='table(projectId,name,lifecycleState)'
```

The Terraform VM is provisioned in `us-central1-b` by default. First search the wrong zone:

```bash
gcloud compute instances list --project="$PROJECT_ID" --zones=us-central1-a --format='table(name,status,zone)'
```

Illustrative result: no matching instance in that zone.

Now search the correct zone:

```bash
gcloud compute instances list --project="$PROJECT_ID" --zones="$VM_ZONE" --format='table(name,status,zone)'
gcloud compute instances describe "$VM_NAME" --project="$PROJECT_ID" --zone="$VM_ZONE" --format='yaml(name,status,zone,networkInterfaces)'
```

Expected: the lab VM appears in the actual zone, and its network interface has no external IPv4 access configuration.

### Optional true cross-project path

If `secondary_project_id` is set to another existing project with billing enabled and suitable permissions, Terraform creates a second VM there. Query each project explicitly:

```bash
SECONDARY_PROJECT="$(terraform output -raw secondary_project_vm_project)"
SECONDARY_VM="$(terraform output -raw secondary_project_vm_name)"
gcloud compute instances list --project="$PROJECT_ID" --format='table(name,status,zone)'
gcloud compute instances list --project="$SECONDARY_PROJECT" --format='table(name,status,zone)'
gcloud compute instances describe "$SECONDARY_VM" --project="$SECONDARY_PROJECT" --zone=us-central1-c --format='yaml(name,status,zone)'
```

If you have no second project, do not invent one or attempt to create it. Use the zone-filter proof and discuss the project selector as the equivalent discovery check. The single-project setup does not by itself prove cross-project discovery.

### Learner conclusion
Before creating a replacement VM, confirm the account/project, zone, name filters, labels and permissions. A resource that is not visible in the current view is not necessarily absent.

---

## GCP-INC-1003 - Service-account least privilege: Editor to custom role

### Objective
Capture the broad before-state, then remove project-level Editor and bind a custom role to one Compute Engine VM only.

### Before-state evidence

```bash
gcloud projects get-iam-policy "$PROJECT_ID" \
  --flatten='bindings[].members' \
  --filter="bindings.members:serviceAccount:${SA_EMAIL}" \
  --format='table(bindings.role,bindings.members)'
```

Expected before-state includes `roles/editor` for the lab service account because `seed_editor_binding=true` by default. Save the output as evidence.

### Re-scope with Terraform

Edit `terraform.tfvars` and change these two settings:

```hcl
seed_editor_binding        = false
enable_custom_role_binding = true
```

Then run:

```bash
terraform plan -out=tfplan
terraform show tfplan
terraform apply tfplan
```

Inspect the plan: the Editor membership for the lab service account should be removed, and the custom role should be attached to the single target VM. Do not apply with `seed_editor_binding=true` after remediation; doing so deliberately recreates the over-permissioned before-state.

### After-state evidence

```bash
gcloud projects get-iam-policy "$PROJECT_ID" \
  --flatten='bindings[].members' \
  --filter="bindings.members:serviceAccount:${SA_EMAIL}" \
  --format='table(bindings.role,bindings.members)'

gcloud compute instances get-iam-policy "$VM_NAME" \
  --project="$PROJECT_ID" --zone="$VM_ZONE" --format='yaml(bindings)'
```

Expected: no project-level `roles/editor` binding for this service account, and a custom role binding at the specific Compute Engine VM.

### Positive and negative permission tests

These tests use service-account impersonation; no service-account key is created. They require `lab_user_email` to match the signed-in account and the optional Token Creator grant to have been deployed.

```bash
gcloud --impersonate-service-account="$SA_EMAIL" \
  compute instances describe "$VM_NAME" --project="$PROJECT_ID" --zone="$VM_ZONE" \
  --format='table(name,status,zone)'
```

Expected: permitted on the target VM (`compute.instances.get`).

```bash
gcloud --impersonate-service-account="$SA_EMAIL" \
  compute instances list --project="$PROJECT_ID" --format='table(name,status,zone)'
```

Expected: permission denied because the custom role is not bound project-wide and does not grant `compute.instances.list`. The service account can now perform only the defined actions on the one VM where the custom role is bound. An error is valid negative-test evidence; capture it without trying a destructive action.

---

## GCP-INC-1004 - IAM Deny precedence over Storage Object Viewer

### Objective
Prove that a valid bucket-level Allow does not succeed when an applicable explicit Deny policy forbids `storage.objects.get`.

### Baseline: the Allow works

```bash
gcloud --impersonate-service-account="$SA_EMAIL" storage cat "$OBJ"
```

Expected before the Deny: the synthetic text is printed. If this test fails, check the object-viewer binding, service-account impersonation grant and API status before introducing Deny.

### Enable the real Deny policy

For a standalone project, use the following in `terraform.tfvars`:

```hcl
enable_iam_deny_policy = true
deny_policy_scope      = "project"
organization_id        = ""
```

Apply:

```bash
terraform plan -out=tfplan
terraform show tfplan
terraform apply tfplan
```

For **exact organization-level scenario parity**, use a dedicated organization-managed training project and set:

```hcl
enable_iam_deny_policy = true
deny_policy_scope      = "organization"
organization_id        = "YOUR_NUMERIC_ORGANIZATION_ID"
```

The signed-in identity must have IAM Deny Policy administration rights at that scope. Do not run the org-level option in a production organization. The rule targets only the unique service account created by this lab, but an org-level policy is inherited through the organization hierarchy. A standalone project's owner may not have permission to create organization-level policies.

### Verify Deny wins

Allow a few minutes for policy propagation, then rerun:

```bash
gcloud --impersonate-service-account="$SA_EMAIL" storage cat "$OBJ"
```

Expected: `PERMISSION_DENIED` / access denied for reading the object, even though the bucket's IAM policy still contains `roles/storage.objectViewer` for that service account. Capture both the unchanged Allow binding and the denied request.

If the Deny API/policy permission is not available, use the IAM Deny Policy Simulator in the Google Cloud Console as a demonstration fallback. State clearly in the lab report whether the proof was a live project-level Deny, a live organization-level Deny, or simulator-only. A project-level Deny proves Deny-over-Allow but does not prove inheritance from the organization.

### Remove Deny after proof

Set `enable_iam_deny_policy = false` and apply, or run `terraform destroy` at the end of the lab. Confirm the Deny policy is removed before reusing the project or identity.

---

## Evidence checklist

For each scenario submit:

- [ ] The exact command and actual output (replace all illustrative IDs with real values).
- [ ] A Console screenshot showing the relevant resource/policy.
- [ ] One or two sentences identifying the root cause and explaining why the result proves the concept.
- [ ] For D5-3, before/after IAM binding output.
- [ ] For D5-4, successful baseline object read and denied read after the Deny policy, plus the Deny policy scope.
- [ ] A note on any limitation: no secondary project, no organization permissions, Policy Simulator fallback, or Cloud SQL tier unavailability.

## Final cleanup checklist

```bash
terraform plan -destroy
terraform destroy
```

After confirmation, check Cloud SQL instances, Compute Engine VMs/disks, Cloud Storage buckets, IAM Deny policies and the IAM page. Remove any resources created manually outside Terraform. Do not delete the entire project unless it was created solely for this lab and your administrator has approved project deletion.
